import os
import sys
import threading
import time
import multiprocessing
from datetime import datetime, timezone
from typing import Callable, Optional, Dict, Any, List
from collections import deque
import platform
import subprocess
import ctypes

# --- Constants ---
WMI_TIMEOUT_MS = 500
POLLING_INTERVAL = 0.01
UNIX_POLLING_INTERVAL = 0.005
WMI_PULSE_INTERVAL = 20
MAX_HISTORY = 100
ANALYSIS_TIMEOUT = 10 # Seconds

def is_admin():
    try:
        if platform.system().lower() == 'windows':
            return ctypes.windll.shell32.IsUserAnAdmin()
        return os.getuid() == 0
    except:
        return False

# Conditional imports
try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

try:
    if platform.system().lower() == 'windows':
        import wmi
        import pythoncom
        HAS_WMI = True
    else:
        HAS_WMI = False
except ImportError:
    HAS_WMI = False

from core.structured_logger import get_logger
logger = get_logger("process_monitor")

from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout

_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="AnalysisWorker")

class BaseProcessMonitor:
    """Base class for platform-specific process monitors"""
    def __init__(self, callback: Optional[Callable] = None, suspicious_keywords: List[str] = None):
        self.callback = callback
        self.suspicious_keywords = suspicious_keywords or []
        self.monitoring = False
        self.processes_detected = 0
        self.suspicious_detected = 0
        self.command_history = deque(maxlen=MAX_HISTORY)
        self.os_type = platform.system().lower()

    def start_monitoring(self):
        raise NotImplementedError

    def stop_monitoring(self):
        self.monitoring = False

    def _is_suspicious(self, command: str) -> bool:
        if not command:
            return False
        cmd_lower = command.lower()
        for keyword in self.suspicious_keywords:
            if keyword.lower() in cmd_lower:
                return True
        return False

    def _handle_suspicious_command(self, command: str, process_info: Dict[str, Any], method: str):
        self.suspicious_detected += 1
        
        if self.callback:
            future = _executor.submit(self.callback, command, process_info)
            try:
                future.result(timeout=ANALYSIS_TIMEOUT)
            except FuturesTimeout:
                # We can't actually 'cancel' a running thread easily in Python,
                # but we stop waiting for it and log the failure.
                logger.warning(
                    f"Analysis for '{command[:50]}' timed out after {ANALYSIS_TIMEOUT}s.",
                    extra={"event": "ANALYSIS_TIMEOUT"}
                )
            except Exception as e:
                logger.error(f"Callback error: {e}", extra={"event": "CALLBACK_ERROR"})

        self.command_history.append({
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'command': command,
            'process': process_info,
            'method': method
        })

    def get_statistics(self) -> Dict[str, Any]:
        return {
            'monitoring': self.monitoring,
            'processes_detected': self.processes_detected,
            'suspicious_detected': self.suspicious_detected,
            'os': self.os_type
        }

class WindowsProcessMonitor(BaseProcessMonitor):
    """Windows-specific monitor using WMI events and Fast Polling"""
    def __init__(self, callback: Optional[Callable] = None, suspicious_keywords: List[str] = None):
        super().__init__(callback, suspicious_keywords)
        self.wmi_thread = None
        self.polling_thread = None

    def start_monitoring(self):
        if self.monitoring:
            return
        self.monitoring = True
        
        if HAS_WMI:
            self.wmi_thread = threading.Thread(target=self._wmi_monitor_loop, daemon=True)
            self.wmi_thread.start()
        
        if HAS_PSUTIL:
            self.polling_thread = threading.Thread(target=self._polling_loop, daemon=True)
            self.polling_thread.start()
            
        logger.info(f"Windows Process Monitor: ACTIVE")

    def _wmi_monitor_loop(self):
        pythoncom.CoInitialize()
        try:
            w = wmi.WMI()
            watcher = w.Win32_Process.watch_for(notification_type="creation", delay_secs=1)
            
            last_pulse = time.time()
            while self.monitoring:
                try:
                    if time.time() - last_pulse > WMI_PULSE_INTERVAL:
                        subprocess.Popen(['cmd.exe', '/c', 'echo ShadowNetPulse'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        last_pulse = time.time()

                    new_process = watcher(timeout_ms=WMI_TIMEOUT_MS)
                    if new_process:
                        name = str(new_process.Name)
                        pid = new_process.ProcessId
                        
                        try:
                            cmdline = getattr(new_process, 'CommandLine', name)
                            cmd = str(cmdline) if cmdline else name
                        except: cmd = name

                        is_suspicious_exe = any(kw.lower() in name.lower() for kw in self.suspicious_keywords)
                        
                        if self._is_suspicious(cmd) or is_suspicious_exe:
                            self.processes_detected += 1
                            p_info = {
                                'pid': pid,
                                'name': name,
                                'cmdline': [cmd],
                                'parent_pid': new_process.ParentProcessId,
                                'timestamp': datetime.now(timezone.utc).isoformat()
                            }
                            self._handle_suspicious_command(cmd, p_info, "WMI")
                except wmi.x_wmi_timed_out: continue
                except Exception as e:
                    if self.monitoring:
                        logger.warning(f"WMI Error: {e}")
                        time.sleep(1)
        except Exception as e:
            logger.error(f"WMI failure: {e}")
        finally:
            pythoncom.CoUninitialize()

    def _polling_loop(self):
        seen_pids = set(p.info['pid'] for p in psutil.process_iter(['pid']))
        while self.monitoring:
            try:
                current_pids = set(psutil.pids())
                new_pids = current_pids - seen_pids
                seen_pids = current_pids

                for pid in new_pids:
                    try:
                        proc = psutil.Process(pid)
                        with proc.oneshot():
                            name = proc.name()
                            cmdline = proc.cmdline()
                            full_cmd = " ".join(cmdline) if cmdline else name
                        
                        is_suspicious_exe = any(kw.lower() in name.lower() for kw in self.suspicious_keywords)
                        if self._is_suspicious(full_cmd) or is_suspicious_exe:
                            self._handle_suspicious_command(full_cmd, {
                                'pid': pid,
                                'name': name,
                                'cmdline': cmdline or [name],
                                'timestamp': datetime.now(timezone.utc).isoformat()
                            }, "Polling")
                    except: continue
            except Exception as e:
                if self.monitoring: logger.error(f"Polling error: {e}")
            time.sleep(POLLING_INTERVAL)

class UnixProcessMonitor(BaseProcessMonitor):
    def __init__(self, callback: Optional[Callable] = None, suspicious_keywords: List[str] = None):
        super().__init__(callback, suspicious_keywords)
        self.polling_thread = None

    def start_monitoring(self):
        if self.monitoring: return
        self.monitoring = True
        if HAS_PSUTIL:
            self.polling_thread = threading.Thread(target=self._polling_loop, daemon=True)
            self.polling_thread.start()
        else:
            logger.error("psutil missing")
            self.monitoring = False

    def _polling_loop(self):
        known_pids = set()
        while self.monitoring:
            try:
                current_pids = set(psutil.pids())
                new_pids = current_pids - known_pids
                for pid in new_pids:
                    try:
                        proc = psutil.Process(pid)
                        cmdline = proc.cmdline()
                        if not cmdline: continue
                        full_cmd = " ".join(cmdline)
                        if self._is_suspicious(full_cmd):
                            self._handle_suspicious_command(full_cmd, {
                                'pid': pid,
                                'name': proc.name(),
                                'cmdline': cmdline,
                                'timestamp': datetime.now(timezone.utc).isoformat()
                            }, "Fast-Poll")
                    except: pass
                known_pids = current_pids
            except Exception as e:
                if self.monitoring: logger.error(f"Unix error: {e}")
            time.sleep(UNIX_POLLING_INTERVAL)

def ProcessMonitor(callback: Optional[Callable] = None, suspicious_keywords: List[str] = None):
    if platform.system().lower() == 'windows':
        return WindowsProcessMonitor(callback, suspicious_keywords)
    return UnixProcessMonitor(callback, suspicious_keywords)
