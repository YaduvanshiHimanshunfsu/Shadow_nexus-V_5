"""
ShadowNet Nexus - Core Modules
Gemini-Powered Anti-Forensics Detection Framework
"""

# NOTE: behavioral_validator is NOT imported here because it runs
# load_dotenv() and module-level code at import time. Import it
# explicitly where needed: from core.behavioral_validator import test_behavior

from .gemini_command_analyzer import GeminiCommandAnalyzer
from .gemini_behavior_analyzer import GeminiBehaviorAnalyzer
from .gemini_report_generator import GeminiReportGenerator
from .proactive_evidence_collector import ProactiveEvidenceCollector
from .emergency_snapshot import EmergencySnapshotEngine
from .alert_manager import AlertManager
from .siem_integration import SIEMIntegration
from .process_monitor import ProcessMonitor as WMIProcessMonitor, ProcessMonitor
from .incident_report_generator import IncidentReportGenerator

__all__ = [
    'GeminiCommandAnalyzer',
    'GeminiBehaviorAnalyzer',
    'GeminiReportGenerator',
    'ProactiveEvidenceCollector',
    'EmergencySnapshotEngine',
    'AlertManager',
    'SIEMIntegration',
    'WMIProcessMonitor',
    'ProcessMonitor',
    'IncidentReportGenerator',
]
