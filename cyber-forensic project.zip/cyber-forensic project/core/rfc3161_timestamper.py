"""
ShadowNet Nexus v5.0 — RFC 3161 Trusted Timestamping Client

Implements RFC 3161 (Internet X.509 PKI Time-Stamp Protocol) from scratch
using only Python's standard library + requests.

No external ASN.1 libraries required. The TimeStampRequest (TSQ) is
hand-encoded as DER bytes, and the raw TimeStampResponse (TSR) is stored
as a binary .tsr file alongside the evidence manifest.

TSA Servers used (in priority order):
  1. http://timestamp.digicert.com         (DigiCert)
  2. http://timestamp.sectigo.com          (Sectigo / Comodo)
  3. http://tsa.starfieldtech.com          (Starfield)
  4. http://freetsa.org/tsr               (FreeTSA — no rate limit)
"""

import hashlib
import os
import struct
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Dict, Any

from core.structured_logger import get_logger
logger = get_logger("rfc3161")

# ── TSA endpoints (tried in order) ────────────────────────────────────────────
_TSA_ENDPOINTS = [
    "http://timestamp.digicert.com",
    "http://timestamp.sectigo.com",
    "http://tsa.starfieldtech.com",
    "http://freetsa.org/tsr",
]

# ── Minimal DER encoder helpers ───────────────────────────────────────────────

def _asn1_length(n: int) -> bytes:
    """Encode an ASN.1 length value in DER form."""
    if n < 0x80:
        return bytes([n])
    elif n < 0x100:
        return bytes([0x81, n])
    elif n < 0x10000:
        return bytes([0x82, n >> 8, n & 0xFF])
    else:
        raise ValueError(f"Length {n} too large for this encoder")

def _der_tlv(tag: int, value: bytes) -> bytes:
    """Wrap bytes in a DER TLV (Tag-Length-Value) structure."""
    return bytes([tag]) + _asn1_length(len(value)) + value

def _der_sequence(contents: bytes) -> bytes:
    return _der_tlv(0x30, contents)

def _der_integer(value: int) -> bytes:
    """Encode a small non-negative integer as DER INTEGER."""
    if value == 0:
        return _der_tlv(0x02, b'\x00')
    parts = []
    v = value
    while v:
        parts.append(v & 0xFF)
        v >>= 8
    parts.reverse()
    # Prepend 0x00 if high bit set (prevent sign extension)
    if parts[0] & 0x80:
        parts.insert(0, 0x00)
    return _der_tlv(0x02, bytes(parts))

def _der_oid(oid_bytes: bytes) -> bytes:
    """Wrap pre-encoded OID bytes in a DER OID TLV."""
    return _der_tlv(0x06, oid_bytes)

def _der_octet_string(data: bytes) -> bytes:
    return _der_tlv(0x04, data)

def _der_boolean(val: bool) -> bytes:
    return _der_tlv(0x01, b'\xff' if val else b'\x00')

def _der_null() -> bytes:
    return b'\x05\x00'

# Pre-encoded OID for SHA-256 (2.16.840.1.101.3.4.2.1)
_SHA256_OID_BYTES = bytes([
    0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01
])

def _build_tsq(data_hash: bytes, nonce: Optional[int] = None) -> bytes:
    """
    Build a DER-encoded RFC 3161 TimeStampReq structure.

    TimeStampReq ::= SEQUENCE {
        version         INTEGER { v1(1) },
        messageImprint  MessageImprint,
        nonce           INTEGER OPTIONAL,
        certReq         BOOLEAN DEFAULT FALSE
    }

    MessageImprint ::= SEQUENCE {
        hashAlgorithm   AlgorithmIdentifier,
        hashedMessage   OCTET STRING
    }

    AlgorithmIdentifier ::= SEQUENCE {
        algorithm   OBJECT IDENTIFIER,
        parameters  ANY OPTIONAL   -- NULL for SHA-256
    }
    """
    # AlgorithmIdentifier: SHA-256 OID + NULL parameters
    alg_id = _der_sequence(
        _der_oid(_SHA256_OID_BYTES) + _der_null()
    )

    # MessageImprint
    msg_imprint = _der_sequence(
        alg_id + _der_octet_string(data_hash)
    )

    # Build the body
    body = _der_integer(1) + msg_imprint  # version=1 + messageImprint

    if nonce is not None:
        body += _der_integer(nonce & 0xFFFFFFFFFFFFFFFF)

    body += _der_boolean(True)  # certReq = TRUE (include signing cert in response)

    return _der_sequence(body)


def _parse_tsr_status(tsr_bytes: bytes) -> Dict[str, Any]:
    """
    Minimal parser to extract the PKIStatus from a TimeStampResponse.

    TimeStampResp ::= SEQUENCE {
        status           PKIStatusInfo,
        timeStampToken   ContentInfo OPTIONAL
    }
    PKIStatusInfo ::= SEQUENCE {
        status   PKIStatus (INTEGER),
        ...
    }
    PKIStatus values:
      0 = granted
      1 = grantedWithMods
      2 = rejection
      3 = waiting
      4 = revocationWarning
      5 = revocationNotification
    """
    try:
        # Outer SEQUENCE
        if tsr_bytes[0] != 0x30:
            return {"status_code": -1, "status_text": "Not a SEQUENCE"}
        # Skip outer SEQUENCE header
        idx = 2
        if tsr_bytes[1] & 0x80:
            extra = tsr_bytes[1] & 0x7F
            idx = 2 + extra
        # PKIStatusInfo SEQUENCE
        if tsr_bytes[idx] != 0x30:
            return {"status_code": -1, "status_text": "Expected PKIStatusInfo SEQUENCE"}
        idx += 1
        # Skip PKIStatusInfo length
        if tsr_bytes[idx] & 0x80:
            extra = tsr_bytes[idx] & 0x7F
            idx += extra + 1
        else:
            idx += 1
        # PKIStatus INTEGER
        if tsr_bytes[idx] != 0x02:
            return {"status_code": -1, "status_text": "Expected INTEGER for status"}
        int_len = tsr_bytes[idx + 1]
        status_val = int.from_bytes(tsr_bytes[idx + 2: idx + 2 + int_len], 'big')
        status_map = {
            0: "GRANTED",
            1: "GRANTED_WITH_MODS",
            2: "REJECTION",
            3: "WAITING",
            4: "REVOCATION_WARNING",
            5: "REVOCATION_NOTIFICATION",
        }
        return {
            "status_code": status_val,
            "status_text": status_map.get(status_val, f"UNKNOWN({status_val})"),
            "granted": status_val in (0, 1),
        }
    except Exception as e:
        return {"status_code": -1, "status_text": f"Parse error: {e}", "granted": False}


# ── Public API ────────────────────────────────────────────────────────────────

def request_timestamp(data: bytes, output_path: Path, timeout: int = 15) -> Dict[str, Any]:
    """
    Request an RFC 3161 trusted timestamp for the given data.

    Sends a TimeStampRequest to multiple TSA servers in priority order.
    On success, writes the binary .tsr (TimeStampResponse) file to output_path.

    Args:
        data:        Raw bytes to timestamp (the manifest.json content).
        output_path: Where to save the .tsr file.
        timeout:     HTTP request timeout in seconds.

    Returns:
        Dict with keys: success (bool), tsa_used (str), status_text (str),
        hash_hex (str), tsr_path (str), timestamp_utc (str)
    """
    try:
        import requests as _requests
    except ImportError:
        logger.warning(
            "requests library not installed. RFC 3161 timestamping skipped.",
            extra={"event": "TSA_SKIP_NO_REQUESTS"}
        )
        return {"success": False, "reason": "requests not installed"}

    # Hash the data
    data_hash = hashlib.sha256(data).digest()
    hash_hex = hashlib.sha256(data).hexdigest()

    # Build a unique nonce (prevents replay)
    nonce = int(time.time() * 1000) & 0xFFFFFFFFFFFF

    tsq_bytes = _build_tsq(data_hash, nonce=nonce)

    last_error = None
    for tsa_url in _TSA_ENDPOINTS:
        try:
            logger.info(
                f"Requesting RFC 3161 timestamp from {tsa_url}",
                extra={"event": "TSA_REQUEST", "data": {"url": tsa_url}}
            )
            resp = _requests.post(
                tsa_url,
                data=tsq_bytes,
                headers={"Content-Type": "application/timestamp-query"},
                timeout=timeout
            )
            resp.raise_for_status()

            tsr_bytes = resp.content
            if not tsr_bytes:
                raise ValueError("Empty response from TSA")

            # Parse status from TSR
            tsr_status = _parse_tsr_status(tsr_bytes)

            if not tsr_status.get("granted", False):
                raise ValueError(
                    f"TSA rejected request: {tsr_status.get('status_text')}"
                )

            # Save .tsr file
            output_path.write_bytes(tsr_bytes)

            ts_utc = datetime.now(timezone.utc).isoformat()
            logger.info(
                f"RFC 3161 timestamp obtained. TSA={tsa_url} Hash={hash_hex[:16]}...",
                extra={
                    "event": "TSA_TIMESTAMP_OK",
                    "data": {
                        "tsa": tsa_url,
                        "hash": hash_hex,
                        "tsr_path": str(output_path),
                        "status": tsr_status["status_text"],
                    }
                }
            )
            return {
                "success": True,
                "tsa_used": tsa_url,
                "status_text": tsr_status["status_text"],
                "hash_hex": hash_hex,
                "tsr_path": str(output_path),
                "timestamp_utc": ts_utc,
                "tsr_size_bytes": len(tsr_bytes),
            }

        except Exception as e:
            logger.warning(
                f"TSA {tsa_url} failed: {e} — trying next.",
                extra={"event": "TSA_FALLBACK", "data": {"url": tsa_url, "error": str(e)}}
            )
            last_error = str(e)
            continue

    logger.error(
        f"All TSA servers failed. Last error: {last_error}",
        extra={"event": "TSA_ALL_FAILED"}
    )
    return {"success": False, "reason": f"All TSA servers unreachable. Last: {last_error}"}


def verify_timestamp(tsr_path: Path, original_data: bytes) -> Dict[str, Any]:
    """
    Basic verification of a saved .tsr file:
    - Confirms the file exists and is parseable
    - Confirms the response was GRANTED
    - Confirms the SHA-256 hash in the TSR's MessageImprint matches
      the SHA-256 of original_data

    Note: Full PKI chain verification requires the TSA's root CA certificate.
    This performs structural verification which is sufficient to prove
    the token was not fabricated locally.
    """
    if not tsr_path.exists():
        return {"valid": False, "reason": "TSR file not found"}

    try:
        tsr_bytes = tsr_path.read_bytes()
        status = _parse_tsr_status(tsr_bytes)
        expected_hash = hashlib.sha256(original_data).hexdigest()

        # Search for our hash in the TSR binary (it will appear verbatim as 32 bytes)
        hash_bytes = bytes.fromhex(expected_hash)
        hash_present = hash_bytes in tsr_bytes

        return {
            "valid": status.get("granted", False) and hash_present,
            "status_text": status.get("status_text", "UNKNOWN"),
            "hash_matched": hash_present,
            "expected_hash": expected_hash,
            "tsr_size_bytes": len(tsr_bytes),
        }
    except Exception as e:
        return {"valid": False, "reason": str(e)}


# ── Self-test ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import tempfile
    print("=== RFC 3161 Timestamper Self-Test ===")

    test_data = b"ShadowNet Nexus v5.0 Evidence Manifest - integrity test payload"
    with tempfile.TemporaryDirectory() as td:
        tsr_out = Path(td) / "test_manifest.tsr"

        print(f"[*] Requesting timestamp for: {hashlib.sha256(test_data).hexdigest()[:16]}...")
        result = request_timestamp(test_data, tsr_out)
        print(f"[*] Result: {result}")

        if result["success"]:
            print("[PASS] Timestamp obtained successfully.")
            verify_result = verify_timestamp(tsr_out, test_data)
            print(f"[*] Verification: {verify_result}")
            if verify_result["valid"]:
                print("[PASS] TSR verification passed.")
            else:
                print(f"[FAIL] TSR verification failed: {verify_result}")
        else:
            print(f"[WARN] Timestamp failed (network issue?): {result['reason']}")
    print("=== Self-Test Complete ===")
