"""
Gemini Report Generator
Generate professional forensic reports automatically
"""

import google.generativeai as genai
import json
from datetime import datetime
from typing import Dict, Any

from utils.model_selector import model_selector


class GeminiReportGenerator:
    """
    Let Gemini write professional, tamper-evident forensic reports
    """
    
    def __init__(self, api_key: str, model_name: str = 'gemini-2.5-flash'):
        """Use Pro model for high-quality report generation"""
        genai.configure(api_key=api_key)
        # Validate model or pick best intelligent one
        self.model_name = model_selector.validate_model(model_name)
        self.model = genai.GenerativeModel(self.model_name)
    
    def generate_executive_summary(self, incident_data: Dict[str, Any]) -> str:
        """
        Generate executive-level incident report
        
        Args:
            incident_data: Incident details
        
        Returns:
            Executive summary text
        """
        from prompts.enhanced_prompts import EXECUTIVE_SUMMARY_PROMPT
        prompt = EXECUTIVE_SUMMARY_PROMPT.format(
            incident_data=json.dumps(incident_data, indent=2)
        )
        
        try:
            response = self.model.generate_content(prompt, request_options={"timeout": 30})
            return response.text.strip()
        except Exception as e:
            return f"""# Executive Summary (LOCAL FALLBACK)
            
## Incident Overview
An incident was detected and summarized using the local fallback engine due to API unavailability.

## Key Findings
- Incident Data: {len(json.dumps(incident_data))} bytes
- Status: Active Investigation
- API Error: {str(e)}

## Recommendations
1. Conduct manual forensic review of raw logs.
2. Verify all emergency snapshots in the evidence directory.
3. Check network connectivity for Gemini AI restoration.
"""
    
    def generate_technical_report(self, incident_data: Dict[str, Any], 
                                  evidence_inventory: Dict[str, Any]) -> str:
        """
        Generate detailed technical forensic report
        """
        prompt = f"""
You are a digital forensics expert writing a technical analysis report.

INCIDENT DATA:
{json.dumps(incident_data, indent=2)}

EVIDENCE INVENTORY:
{json.dumps(evidence_inventory, indent=2)}

Write a comprehensive technical forensic report including:

1. **Executive Summary**
   - Brief technical overview

2. **Evidence Summary**
   - Chain of evidence trail
   - Evidence integrity verification
   - List of artifacts collected

3. **Attack Timeline**
   - Detailed chronological sequence
   - Evidence supporting each event
   - Confidence levels

4. **Technical Analysis**
   - Initial access vector
   - Privilege escalation methods
   - Lateral movement techniques
   - Anti-forensics techniques employed
   - Data exfiltration (if any)
   - Tools and malware used

5. **Indicators of Compromise (IOCs)**
   - File hashes
   - IP addresses
   - Domain names
   - Registry keys
   - Process names

6. **Threat Actor Attribution**
   - Primary attribution with confidence level
   - Evidence supporting attribution
   - Known TTPs of attributed actor

7. **Recommendations**
   - Immediate containment actions
   - Short-term remediation
   - Long-term security improvements
   - Detection rule deployment

Format as a professional forensic report suitable for:
- Internal security teams
- Legal proceedings
- Insurance claims
- Regulatory compliance

Use proper forensic report structure and terminology.
Write in markdown format with clear sections.
"""
        
        try:
            response = self.model.generate_content(prompt, request_options={"timeout": 45})
            return response.text.strip()
        except Exception as e:
            return f"""# Technical Forensic Report (LOCAL FALLBACK)

## 1. Executive Summary
Local diagnostic report generated due to API timeout ({str(e)}).

## 2. Evidence Inventory
Total Artifacts Tracked: {len(evidence_inventory.get('artifacts', []))}
Total Snapshots Found: {len(evidence_inventory.get('snapshots', []))}

## 3. Preliminary Analysis
Suspicious activity confirmed via local detection rules. Manual semantic analysis required.
"""
    
    def generate_ioc_feed(self, incident_data: Dict[str, Any]) -> str:
        """
        Generate STIX/machine-readable IOC feed
        """
        prompt = f"""
You are generating a threat intelligence feed in STIX 2.1 format.

INCIDENT DATA:
{json.dumps(incident_data, indent=2)}

Extract all Indicators of Compromise (IOCs) and format as STIX 2.1 JSON.

Include:
- Indicator objects (file hashes, IPs, domains, URLs)
- Malware objects (if malware identified)
- Attack Pattern objects (TTPs used)
- Threat Actor object (attributed actor)
- Relationship objects (linking indicators to actors and patterns)

Generate valid STIX 2.1 JSON that can be:
1. Imported into threat intelligence platforms
2. Shared via TAXII servers
3. Used to update detection rules

Ensure all STIX objects have:
- Unique IDs
- Timestamps
- Confidence scores
- Descriptions
- Proper relationships

Output valid STIX 2.1 JSON only.
"""
        
        try:
            response = self.model.generate_content(prompt, request_options={"timeout": 20})
            return response.text.strip()
        except Exception as e:
            return json.dumps({
                "type": "bundle",
                "id": "bundle--fallback",
                "objects": [],
                "error": f"STIX generation failed: {str(e)}"
            }, indent=2)
    
    def generate_incident_summary(self, incident_data: Dict[str, Any]) -> str:
        """
        Generate concise incident summary for alerts/notifications
        """
        prompt = f"""
Generate a concise incident summary (3-5 sentences) for security team notification.

INCIDENT DATA:
{json.dumps(incident_data, indent=2)}

Include:
- What happened
- Severity
- Threat actor (if known)
- Current status
- Immediate action required

Keep it brief and actionable. Use clear, direct language.
"""
        
        try:
            response = self.model.generate_content(prompt, request_options={"timeout": 10})
            return response.text.strip()
        except Exception as e:
            return f"CRITICAL: {incident_data.get('type', 'Unknown Threat')} detected. Local fallback mode active (API Error: {str(e)})."
    
    def generate_timeline_visualization_data(self, timeline: list) -> Dict[str, Any]:
        """
        Generate data structure for timeline visualization
        """
        prompt = f"""
Convert this attack timeline into a visualization-ready format.

TIMELINE:
{json.dumps(timeline, indent=2)}

Generate JSON for timeline visualization with:
- Events grouped by attack phase
- Color coding by severity
- Icons for event types
- Tooltips with details

Respond in JSON:
{{
  "events": [
    {{
      "timestamp": "ISO timestamp",
      "title": "brief title",
      "description": "details",
      "phase": "reconnaissance|initial_access|execution|persistence|etc.",
      "severity": "CRITICAL|HIGH|MEDIUM|LOW",
      "icon": "icon name",
      "color": "hex color code"
    }}
  ],
  "phases": ["ordered list of attack phases"],
  "summary": "overall timeline summary"
}}

IMPORTANT: Respond ONLY with valid JSON.
"""
        
        try:
            response = self.model.generate_content(prompt, request_options={"timeout": 15})
            response_text = response.text.strip()
            
            # Parse JSON
            import re
            match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if match:
                return json.loads(match.group())
            return json.loads(response_text.strip())
        except Exception as e:
            # Local mapping fallback
            fallback_events = []
            for item in timeline:
                fallback_events.append({
                    "timestamp": item.get('time'),
                    "title": item.get('event'),
                    "severity": "HIGH",
                    "color": "#FF0000"
                })
            return {
                "events": fallback_events,
                "summary": f"Local timeline (API Error: {str(e)})",
                "fallback": True
            }
