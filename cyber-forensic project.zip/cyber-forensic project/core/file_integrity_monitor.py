import os
import time
import threading
import platform
from pathlib import Path
from typing import Dict, Any, List, Callable, Optional
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from core.structured_logger import get_logger

logger = get_logger("fim")

class SecurityEventHandler(FileSystemEventHandler):
    """Handles file system events for the FIM"""
    def __init__(self, callback: Callable, suspicious_extensions: List[str] = None):
        super().__init__()
        self.callback = callback
        self.suspicious_extensions = suspicious_extensions or ['.exe', '.dll', '.ps1', '.bat', '.sh']

    def _process_event(self, event, event_type: str):
        if event.is_directory:
            return

        file_path = event.dest_path if hasattr(event, 'dest_path') else event.src_path
        _, ext = os.path.splitext(file_path)
        
        # We trigger on suspicious extensions or if files are deleted (potential wiping)
        if ext.lower() in self.suspicious_extensions or event_type == 'DELETED':
            incident_data = {
                'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S%z'),
                'type': 'fim_alert',
                'event': event_type,
                'file_path': file_path,
                'command': f'FIM_ALERT: {event_type} on {file_path}',
                'process_info': {
                    'name': 'FIM_SYSTEM',
                    'pid': os.getpid(),
                    'user': 'SYSTEM',
                },
                'category': 'file_integrity_anomaly',
                'verdict': 'FILE_SYSTEM_ANOMALY',
                'confidence': 0.85
            }
            try:
                self.callback(incident_data)
            except Exception as e:
                logger.error(f"FIM callback failed: {e}")

    def on_created(self, event):
        self._process_event(event, "CREATED")

    def on_modified(self, event):
        self._process_event(event, "MODIFIED")

    def on_deleted(self, event):
        self._process_event(event, "DELETED")

    def on_moved(self, event):
        self._process_event(event, "MOVED")

class FileIntegrityMonitor:
    """
    Cross-Platform File Integrity Monitor mapping to `directories_to_monitor`
    Replaces raw NTFS scanning for standard deployments.
    """
    def __init__(self, config: Dict[str, Any], callback: Callable):
        self.config = config.get('shadownet', {}).get('monitoring', {})
        self.callback = callback
        self.enabled = self.config.get('enable_file_monitoring', True)
        
        # Load directories from config, fallback to desktop if empty
        self.directories = self.config.get('directories_to_monitor', [])
        if not self.directories:
            if platform.system() == 'Windows':
                desktop = os.path.join(os.environ.get('USERPROFILE', 'C:\\'), 'Desktop')
                self.directories = [desktop]
            else:
                self.directories = ['/var/log']

        self.observer = None
        self.monitoring = False

    def start_monitoring(self):
        if not self.enabled or self.monitoring:
            return

        self.observer = Observer()
        handler = SecurityEventHandler(self.callback)

        valid_dirs = 0
        for directory in self.directories:
            path = Path(directory)
            if path.exists() and path.is_dir():
                try:
                    self.observer.schedule(handler, str(path), recursive=True)
                    valid_dirs += 1
                    logger.info(f"FIM: Watching {path}")
                except Exception as e:
                    logger.error(f"FIM Error watching {path}: {e}")
            else:
                logger.warning(f"FIM: Directory {path} does not exist. Skipping.")

        if valid_dirs > 0:
            self.observer.start()
            self.monitoring = True
            logger.info("File Integrity Monitor: ACTIVE (Cross-Platform)")
        else:
            logger.warning("FIM: No valid directories to monitor.")

    def stop_monitoring(self):
        if self.observer and self.monitoring:
            self.observer.stop()
            self.observer.join()
            self.monitoring = False
            logger.info("File Integrity Monitor: STOPPED")
