import threading, time, hashlib, json
from typing import Any
from collections import OrderedDict
from core.structured_logger import get_logger

logger = get_logger("alert_dedup")

class AlertDeduplicator:
    def __init__(self, window_seconds: float = 300.0, max_size: int = 1000):
        self.window = window_seconds
        self.max_size = max_size
        # Use OrderedDict for simple LRU behavior
        self._seen: OrderedDict[str, float] = OrderedDict()
        self._lock = threading.Lock()

    def _fingerprint(self, alert_type: str, data: Any) -> str:
        # Create a stable hash of the alert type and relevant data
        data_copy = data.copy() if isinstance(data, dict) else data
        if isinstance(data_copy, dict):
            # Exclude transient fields
            data_copy.pop('timestamp', None)
            data_copy.pop('ts', None)
            data_copy.pop('snapshot_id', None)
            
        key = json.dumps(
            {"type": alert_type, "data": data_copy},
            sort_keys=True, default=str
        )
        return hashlib.sha256(key.encode()).hexdigest()[:16]

    def is_duplicate(self, alert_type: str, data: Any) -> bool:
        fp = self._fingerprint(alert_type, data)
        now = time.monotonic()
        
        with self._lock:
            # 1. Prune expired entries
            expired = [k for k, v in self._seen.items() if now - v > self.window]
            for k in expired:
                self._seen.pop(k)
            
            # 2. Check for duplicate
            if fp in self._seen:
                # Update timestamp and move to end (Lately Used)
                self._seen.move_to_end(fp)
                self._seen[fp] = now
                return True
            
            # 3. Size enforcement (LRU eviction if still too big after pruning)
            if len(self._seen) >= self.max_size:
                self._seen.popitem(last=False) # Remove oldest
                
            self._seen[fp] = now
            return False

    def should_alert(self, alert_type: str, data: Any) -> bool:
        return not self.is_duplicate(alert_type, data)

# Global singleton
deduplicator = AlertDeduplicator(window_seconds=300.0, max_size=1000)
