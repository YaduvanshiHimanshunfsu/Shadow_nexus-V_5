import os
import shutil
import subprocess
import threading
import time
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List, Optional
import platform
from concurrent.futures import ThreadPoolExecutor

from core.structured_logger import get_logger
logger = get_logger("emergency_snapshot")

class EmergencySnapshotEngine:
    """
    Captures evidence in <100ms before anti-forensics commands execute
    Automatically adapts to Windows, Linux, or Mac
    """
    
    def __init__(self, evidence_vault_path: str = "./evidence", capture_network: bool = True):
        self.vault_path = Path(evidence_vault_path)
        self.capture_network = capture_network
        self.os_type = platform.system().lower()
        self.snapshots_dir = self.vault_path / "emergency_snapshots"
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)
        self.thread_pool = ThreadPoolExecutor(max_workers=10)
        
    def check_disk_space(self, required_mb: int = 100):
        """Ensure sufficient disk space before capturing evidence"""
        usage = shutil.disk_usage(self.snapshots_dir)
        free_mb = usage.free / (1024 * 1024)
        if free_mb < required_mb:
            raise IOError(f"Insufficient disk space: {free_mb:.1f}MB free, need {required_mb}MB")

    def emergency_snapshot(self, threat_type: str, command: str, process_info: Dict, max_retries: int = 3) -> str:
        """
        Execute emergency snapshot with retry logic and exponential backoff
        """
        for attempt in range(max_retries):
            try:
                self.check_disk_space(required_mb=100)
                return self._execute_snapshot(threat_type, command, process_info)
            except Exception as e:
                logger.error(f"Snapshot attempt {attempt+1} failed: {e}")
                if attempt == max_retries - 1:
                    logger.critical("All snapshot attempts failed. Evidence may be lost.")
                    # Return a dummy ID so the system can continue
                    return f"ERROR-{int(time.time())}"
                time.sleep(2 ** attempt) # Exponential backoff
        return "ERROR"

    def _execute_snapshot(self, threat_type: str, command: str, process_info: Dict) -> str:
        """Internal execution of the snapshot logic"""
        snapshot_id = f"SNAP-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}"
        snapshot_dir = self.snapshots_dir / snapshot_id
        snapshot_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"⚡ EMERGENCY SNAPSHOT TRIGGERED: {snapshot_id} (Type: {threat_type})")
        start_time = time.time()
        
        # Create incident metadata file
        metadata_file = snapshot_dir / "incident_metadata.json"
        import json
        metadata = {
            'snapshot_id': snapshot_id,
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'threat_type': threat_type,
            'command': command,
            'process_info': process_info,
            'os_type': self.os_type,
            'evidence_collected': []
        }
        
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        futures = []
        evidence_types = []
        
        # Parallel capture tasks
        tasks = [
            (self._snapshot_event_logs, (snapshot_dir,), 'event_logs'),
            (self._snapshot_process_state, (snapshot_dir, process_info), 'process_state')
        ]
        
        if threat_type in ['vss_deletion', 'vss_manipulation']:
            tasks.append((self._snapshot_vss_state, (snapshot_dir,), 'vss_state'))
        
        if threat_type == 'file_wiping':
            tasks.append((self._snapshot_filesystem_metadata, (snapshot_dir,), 'filesystem_metadata'))
        
        if self.capture_network:
            tasks.append((self._snapshot_network_state, (snapshot_dir,), 'network_state'))
        
        for func, args, etype in tasks:
            futures.append(self.thread_pool.submit(func, *args))
            evidence_types.append(etype)
        
        # Wait for completion (with timeout)
        for future in futures:
            try:
                future.result(timeout=10)
            except Exception as e:
                logger.warning(f"Snapshot sub-task failed: {e}")
        
        # Update metadata
        metadata['evidence_collected'] = evidence_types
        metadata['capture_duration_ms'] = (time.time() - start_time) * 1000
        
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        try:
            # Protect files
            for root, dirs, files in os.walk(snapshot_dir):
                for f in files:
                    os.chmod(os.path.join(root, f), stat.S_IREAD | stat.S_IRGRP | stat.S_IROTH)
            # Protect directory
            os.chmod(snapshot_dir, stat.S_IREAD | stat.S_IEXEC | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)
        except Exception as e:
            logger.warning(f"Failed to set write protection: {e}")

        logger.info(f"✅ Snapshot completed in {metadata['capture_duration_ms']:.1f}ms")
        return snapshot_id
    
    def _snapshot_event_logs(self, snapshot_dir: Path):
        """Snapshot event logs (OS-specific)"""
        try:
            if self.os_type == 'windows':
                self._snapshot_windows_event_logs(snapshot_dir)
            elif self.os_type == 'linux':
                self._snapshot_linux_logs(snapshot_dir)
            elif self.os_type == 'darwin':  # Mac
                self._snapshot_mac_logs(snapshot_dir)
        except Exception as e:
            logger.warning(f"Log snapshot failed: {e}")
    
    def _snapshot_windows_event_logs(self, snapshot_dir: Path):
        """Snapshot Windows event logs - ONLY .evtx files"""
        logs_dir = snapshot_dir / "event_logs"
        logs_dir.mkdir(exist_ok=True)
        
        log_types = ['Security', 'System', 'Application']
        
        for log_type in log_types:
            try:
                output_file = logs_dir / f"{log_type}.evtx"
                subprocess.run([
                    'wevtutil', 'epl', log_type, str(output_file)
                ], capture_output=True, timeout=5, text=True, check=False)
            except Exception as e:
                logger.warning(f"Failed to export {log_type}: {e}")
    
    def _snapshot_linux_logs(self, snapshot_dir: Path):
        """Snapshot Linux system logs"""
        logs_dir = snapshot_dir / "system_logs"
        logs_dir.mkdir(exist_ok=True)
        
        log_files = ['/var/log/auth.log', '/var/log/syslog', '/var/log/kern.log']
        for log_file in log_files:
            try:
                if os.path.exists(log_file):
                    shutil.copy2(log_file, logs_dir / os.path.basename(log_file))
            except Exception as e:
                logger.warning(f"Failed to copy {log_file}: {e}")
    
    def _snapshot_mac_logs(self, snapshot_dir: Path):
        """Snapshot Mac system logs"""
        logs_dir = snapshot_dir / "system_logs"
        logs_dir.mkdir(exist_ok=True)
        try:
            output_file = logs_dir / "system.log"
            with open(output_file, 'w') as log_out:
                subprocess.run(['log', 'show', '--last', '1h'], stdout=log_out, timeout=5)
        except Exception as e:
            logger.warning(f"Mac log snapshot failed: {e}")
    
    def _snapshot_vss_state(self, snapshot_dir: Path):
        """Snapshot Volume Shadow Copy state (Windows only)"""
        if self.os_type != 'windows': return
        try:
            vss_file = snapshot_dir / "vss_state.txt"
            result = subprocess.run(['vssadmin', 'list', 'shadows'], capture_output=True, text=True, timeout=5)
            vss_file.write_text(result.stdout)
        except Exception as e:
            logger.warning(f"VSS snapshot failed: {e}")
    
    def _snapshot_filesystem_metadata(self, snapshot_dir: Path):
        """Snapshot filesystem metadata"""
        try:
            metadata_file = snapshot_dir / "filesystem_metadata.txt"
            if self.os_type == 'windows':
                result = subprocess.run(['cmd', '/c', 'dir', '/s', '/a', 'C:\\'], capture_output=True, text=True, timeout=10)
            else:
                result = subprocess.run(['find', '/', '-type', 'f', '-ls'], capture_output=True, text=True, timeout=10)
            metadata_file.write_text(result.stdout[:100000])
        except Exception as e:
            logger.warning(f"Filesystem snapshot failed: {e}")
    
    def _snapshot_process_state(self, snapshot_dir: Path, process_info: Dict):
        """Snapshot current process state"""
        try:
            import psutil
            import json
            state_file = snapshot_dir / "process_state.json"
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'username']):
                try: processes.append(proc.info)
                except: pass
            
            state = {
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'trigger_process': process_info,
                'all_processes': processes[:100],
                'system_info': {'hostname': platform.node(), 'os': platform.system()}
            }
            with open(state_file, 'w') as f:
                json.dump(state, f, indent=2)
        except Exception as e:
            logger.warning(f"Process state snapshot failed: {e}")

    def _snapshot_network_state(self, snapshot_dir: Path):
        """Snapshot current network state"""
        try:
            import psutil
            import json
            network_file = snapshot_dir / "network_state.json"
            connections = []
            for conn in psutil.net_connections(kind='inet'):
                try: 
                    connections.append({
                        'laddr': f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else None,
                        'raddr': f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else None,
                        'status': conn.status,
                        'pid': conn.pid
                    })
                except: pass
            with open(network_file, 'w') as f:
                json.dump(connections, f, indent=2)
        except Exception as e:
            logger.warning(f"Network state snapshot failed: {e}")
    
    def get_snapshot_info(self, snapshot_id: str) -> Dict[str, Any]:
        """Get information about a snapshot"""
        snapshot_dir = self.snapshots_dir / snapshot_id
        if not snapshot_dir.exists(): return {'error': 'Snapshot not found'}
        total_size = sum(f.stat().st_size for f in snapshot_dir.rglob('*') if f.is_file())
        return {
            'snapshot_id': snapshot_id,
            'path': str(snapshot_dir),
            'total_size_mb': total_size / (1024 * 1024),
            'created': datetime.fromtimestamp(snapshot_dir.stat().st_ctime, tz=timezone.utc).isoformat()
        }
    
    def list_snapshots(self) -> List[Dict[str, Any]]:
        """List all emergency snapshots"""
        snapshots = []
        for snapshot_dir in self.snapshots_dir.iterdir():
            if snapshot_dir.is_dir() and snapshot_dir.name.startswith('SNAP-'):
                snapshots.append(self.get_snapshot_info(snapshot_dir.name))
        return sorted(snapshots, key=lambda x: x['created'], reverse=True)
