import json, hashlib, logging, threading, os
from datetime import datetime, timezone
from pathlib import Path
from logging.handlers import RotatingFileHandler

SESSION_ID = f"SNX-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}"
_seq_lock = threading.Lock()
_seq = 0

FORENSIC = 35  # between WARNING(30) and ERROR(40)
logging.addLevelName(FORENSIC, "FORENSIC")

class JSONLineFormatter(logging.Formatter):
    """Log record to JSON string conversion."""
    def format(self, record: logging.LogRecord):
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "module": record.module,
            "message": record.getMessage(),
            "pid": os.getpid(),
            "thread_name": record.threadName
        }
        if hasattr(record, "event"):
            entry["event"] = record.event
        if hasattr(record, "data"):
            entry["data"] = record.data
        return json.dumps(entry, default=str)

class ForensicHashChainHandler(RotatingFileHandler):
    """
    Writes forensic findings with hash chain.
    Each entry includes sha256 of the previous entry.
    A broken chain proves tampering at that point.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._prev_hash = "0" * 64
        self._chain_lock = threading.Lock()

    def emit(self, record: logging.LogRecord):
        if record.levelno != FORENSIC:
            return
        
        try:
            if self.shouldRollover(record):
                self.doRollover()
        except Exception:
            self.handleError(record)
            return

        with self._chain_lock:
            try:
                # Use the formatter for base JSON
                entry_str = self.format(record)
                entry = json.loads(entry_str)
                entry["prev_hash"] = self._prev_hash
                # Sort keys for deterministic hashing
                entry_final = json.dumps(entry, sort_keys=True, default=str)
                self._prev_hash = hashlib.sha256(
                    entry_final.encode()
                ).hexdigest()
                self.stream.write(entry_final + "\n")
                self.stream.flush()
            except Exception:
                self.handleError(record)

def verify_log_chain(log_path: Path) -> dict:
    """
    Read forensic log and verify every hash chain link across rotated files.
    """
    if not log_path.exists():
        return {"status": "ERROR", "message": "Log file not found"}
        
    # Collect and sort all rotated files in chronological order
    # (findings.jsonl.10, ..., findings.jsonl.1, findings.jsonl)
    log_files = []
    parent = log_path.parent
    base_name = log_path.name
    for f in parent.glob(f"{base_name}*"):
        log_files.append(f)
    
    # Custom sort: .10, .2, .1, base
    def sort_key(p: Path):
        suffix = p.suffix
        if suffix == '.jsonl': return 999999
        try:
            return -int(suffix.strip('.'))
        except:
            return 999998

    log_files.sort(key=sort_key)

    entries = []
    for lf in log_files:
        try:
            with open(lf, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        entries.append(json.loads(line))
        except:
            continue

    if not entries:
        return {"status": "INTACT", "total_entries": 0}

    tampered = []
    prev_hash_pool = {"0" * 64} # Allow chain start/rotation points

    current_prev_hash = "0" * 64
    for i, entry in enumerate(entries):
        claimed_prev = entry.get("prev_hash", "")
        
        # Verify link
        if claimed_prev != current_prev_hash:
            # If it's a "0" block, it might be a rotation/session start
            if claimed_prev == "0" * 64:
                # Reset chain tracking for new segment
                pass
            else:
                tampered.append(entry.get("seq", i))
        
        # Recompute hash of this entry for next step
        entry_copy = {k: v for k, v in entry.items()}
        current_prev_hash = hashlib.sha256(
            json.dumps(entry_copy, sort_keys=True, default=str).encode()
        ).hexdigest()

    return {
        "status": "TAMPERED" if tampered else "INTACT",
        "total_entries": len(entries),
        "first_break": tampered[0] if tampered else None,
        "tampered_entries": tampered
    }

def get_logger(module_name: str) -> logging.Logger:
    """Get a configured logger for a module."""
    logger = logging.getLogger(module_name)
    # Ensure root is configured
    if not logging.getLogger().handlers:
        setup_logging(Path("evidence/logs"))
    return logger

def setup_logging(log_dir: Path, max_bytes: int = 100*1024*1024,
                  backup_count: int = 10):
    log_dir.mkdir(parents=True, exist_ok=True)
    formatter = JSONLineFormatter()

    # Primary JSON log
    primary = RotatingFileHandler(
        log_dir / "shadownet.jsonl",
        maxBytes=max_bytes,
        backupCount=backup_count
    )
    primary.setFormatter(formatter)
    primary.setLevel(logging.DEBUG)

    # Forensic hash-chain log
    forensic = ForensicHashChainHandler(
        log_dir / "forensic_findings.jsonl",
        maxBytes=max_bytes,
        backupCount=backup_count
    )
    forensic.setFormatter(formatter)
    forensic.setLevel(FORENSIC)

    # Console (human-readable summary only)
    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(module)s: %(message)s"
    ))
    console.setLevel(logging.INFO)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    # Clear existing handlers to avoid duplicates during re-setup
    root.handlers = []
    root.addHandler(primary)
    root.addHandler(forensic)
    root.addHandler(console)
