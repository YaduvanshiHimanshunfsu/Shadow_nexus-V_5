"""
ShadowNet Nexus v5.0 — Real-Time Behavior Monitor

NOVELTY CLAIM (Q1 2026):
No system in existence — commercial or open-source — performs all of 
the following simultaneously on a LIVE running system:
  - Raw $MFT/$USN/$LogFile binary parsing without disk imaging
  - Cluster-level entropy mapping with K-S uniformity testing
  - Wipe pattern signature detection in slack space
  - Real OS-level input hook keystroke dynamics classification
  - LLM forensic narrative synthesis across all artifact streams

This module installs a low-level input hook to capture keystroke dynamics 
and classify them as human or synthetic (bot/keylogger) using 
statistical analysis and Gaussian Mixture Models (GMM).
"""

import os
import time
import threading
import platform
import ctypes
import ctypes.wintypes as wintypes  # imported at module level so stop() can use it safely
import numpy as np
import scipy.stats as stats
from collections import deque
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
import json
from pathlib import Path
from sklearn.mixture import GaussianMixture

from core.structured_logger import get_logger, FORENSIC
logger = get_logger("behavior_monitor")

class RealtimeBehaviorMonitor(threading.Thread):
    def __init__(self, config: Dict[str, Any], behavioral_alert_callback=None):
        super().__init__(daemon=True, name="BehaviorMonitor")
        self.config = config.get('shadownet_v5', {}).get('realtime_behavior', {})
        self.callback = behavioral_alert_callback
        self.enabled = self.config.get('enabled', True)
        self.window_size = self.config.get('analysis_window_keystrokes', 50)
        self.alert_threshold = self.config.get('bot_confidence_alert_threshold', 0.65)
        
        self.timing_buffer = deque(maxlen=200)
        self.os_type = platform.system()
        
        self._hook_handle = None
        self._hook_thread = None
        self._hook_active = threading.Event()  # FIX 7
        self._windows_hook_thread_id = None    # FIX 7
        
    def start(self):
        if not self.enabled: return
        
        logger.info(f"Starting {self.os_type} input hook...", extra={"event": "MODULE_START"})
        if self.os_type == 'Windows':
            self._start_windows_hook()
        elif self.os_type == 'Linux':
            self._start_linux_hook()
            
        super().start() # Calls run() in background

    def run(self):
        self._analysis_loop()

    def _start_windows_hook(self):
        import ctypes.wintypes as wintypes
        
        WH_KEYBOARD_LL = 13
        WM_KEYDOWN = 0x0100
        HC_ACTION = 0
        
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        
        # FIX 7: Explicitly define argtypes/restypes for 64-bit compatibility
        # Prevents handle truncation which causes [WinError 126]
        HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_longlong, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
        
        user32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
        user32.SetWindowsHookExW.restype = wintypes.HHOOK if hasattr(wintypes, 'HHOOK') else ctypes.c_void_p
        
        kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
        kernel32.GetModuleHandleW.restype = wintypes.HMODULE
        
        user32.CallNextHookEx.argtypes = [wintypes.HHOOK if hasattr(wintypes, 'HHOOK') else ctypes.c_void_p, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
        user32.CallNextHookEx.restype = ctypes.c_longlong
        
        def hook_callback(nCode, wParam, lParam):
            if nCode == HC_ACTION and wParam == WM_KEYDOWN:
                self.timing_buffer.append(time.perf_counter_ns())
            # In Python, if we don't have the handle, passing None is acceptable for LL hooks
            return user32.CallNextHookEx(None, nCode, wParam, lParam)
            
        self._hook_proc = HOOKPROC(hook_callback)
        
        def hook_thread_main():
            self._windows_hook_thread_id = kernel32.GetCurrentThreadId()
            h_mod = kernel32.GetModuleHandleW(None)
            
            self._hook_handle = user32.SetWindowsHookExW(
                WH_KEYBOARD_LL, self._hook_proc, h_mod, 0
            )
            
            if not self._hook_handle:
                err = ctypes.WinError()
                logger.error(f"Windows Hook Error: {err}", extra={"event": "HOOK_ERROR"})
                return
            
            self._hook_active.set() # Signal that hook is established
            msg = wintypes.MSG()
            while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
            
            if self._hook_handle:
                user32.UnhookWindowsHookEx(self._hook_handle)
                self._hook_handle = None
                logger.info("Windows keyboard hook released.", extra={"event": "HOOK_RELEASED"})
                
        self._hook_thread = threading.Thread(target=hook_thread_main, daemon=True, name="KeyboardHook")
        self._hook_thread.start()

    def _start_linux_hook(self):
        def _evdev_reader():
            try:
                from evdev import InputDevice, ecodes, list_devices
            except ImportError:
                logger.warning(
                    "evdev not installed. Linux keystroke hook unavailable. "
                    "pip install evdev (requires input group membership).",
                    extra={"event": "EVDEV_MISSING"})
                return

            keyboard = None
            try:
                for path in list_devices():
                    try:
                        dev = InputDevice(path)
                        caps = dev.capabilities()
                        if (ecodes.EV_KEY in caps and
                                ecodes.KEY_A in caps[ecodes.EV_KEY] and
                                ecodes.KEY_ENTER in caps[ecodes.EV_KEY]):
                            keyboard = dev
                            break
                    except Exception:
                        continue
            except Exception as e:
                logger.error(f"evdev device discovery failed: {e}",
                    extra={"event": "EVDEV_DISCOVERY_ERROR"})
                return

            if not keyboard:
                logger.warning(
                    "No keyboard found via evdev. "
                    "Ensure user is in 'input' group: "
                    "sudo usermod -aG input $USER && reboot",
                    extra={"event": "NO_KEYBOARD"})
                return

            logger.info(f"Linux keyboard hook active: {keyboard.path}",
                extra={"event": "HOOK_ACTIVE"})

            import select
            while self._hook_active.is_set():
                try:
                    r, _, _ = select.select([keyboard.fd], [], [], 1.0)
                    if r:
                        for event in keyboard.read():
                            if (event.type == ecodes.EV_KEY and
                                    event.value == 1):
                                self.timing_buffer.append(
                                    time.perf_counter_ns())
                except Exception as e:
                    logger.error(f"evdev read error: {e}",
                        extra={"event": "EVDEV_READ_ERROR"})
                    time.sleep(1)

        self._hook_active.set()
        self._hook_thread = threading.Thread(
            target=_evdev_reader, daemon=True, name="LinuxKeyboardHook")
        self._hook_thread.start()

    def stop(self):
        """Securely shuts down hooks and analysis (FIX 7)."""
        logger.info("Stopping behavior monitor hooks...", extra={"event": "SHUTDOWN"})
        self._hook_active.clear()
        if self.os_type == 'Windows' and self._windows_hook_thread_id:
            WM_QUIT = 0x0012
            user32 = ctypes.windll.user32
            user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
            user32.PostThreadMessageW(self._windows_hook_thread_id, WM_QUIT, 0, 0)
            if self._hook_thread:
                self._hook_thread.join(timeout=2)

    def _analysis_loop(self):
        last_processed_count = 0
        from core.watchdog import watchdog
        
        while self._hook_active.is_set():
            watchdog.heartbeat("behavior_monitor")
            try:
                current_count = len(self.timing_buffer)
                if current_count >= self.window_size and current_count != last_processed_count:
                    analysis = self.analyze_keystrokes()
                    
                    if analysis['verdict'] != 'HUMAN' and analysis['confidence'] >= self.alert_threshold:
                        logger.log(FORENSIC, f"Behavioral Anomaly: {analysis['verdict']}", extra={"event": "DETECTION", "data": analysis})
                        if self.callback:
                            self.callback(analysis)

                    try:
                        out_path = Path(self.config.get(
                            'output_file',
                            'evidence/artifacts/behavioral_anomalies.jsonl'))
                        out_path.parent.mkdir(parents=True, exist_ok=True)
                        with open(out_path, 'a') as f:
                            f.write(json.dumps(analysis, default=str) + "\n")
                    except Exception as e:
                        logger.error(f"Failed to write behavioral anomaly: {e}",
                            extra={"event": "OUTPUT_WRITE_ERROR"})
                        
                    last_processed_count = current_count
            except Exception as e:
                logger.error(f"Behavior Analysis Error: {e}", extra={"event": "ERROR"})
            time.sleep(1)

    def analyze_keystrokes(self) -> Dict[str, Any]:
        timings = list(self.timing_buffer)
        if len(timings) < 10:
            return {"verdict": "HUMAN", "confidence": 0.5, "reason": "Insufficient data", "sample_size": 0}
            
        iki_ms = np.diff(np.array(timings)) / 1e6
        iki_ms = iki_ms[iki_ms < 2000] # Ignore pauses
        
        if len(iki_ms) < 5:
            return {"verdict": "INSUFFICIENT_DATA", "sample_size": 0}

        mean_iki = float(np.mean(iki_ms))
        std_iki = float(np.std(iki_ms))
        cv = std_iki / mean_iki if mean_iki > 0 else 0
        kurt = float(stats.kurtosis(iki_ms))
        
        try:
            X = iki_ms.reshape(-1, 1)
            gmm1 = GaussianMixture(n_components=1, random_state=42).fit(X)
            gmm2 = GaussianMixture(n_components=2, random_state=42).fit(X)
            # Higher BIC is worse. Lower BIC is better.
            is_bimodal = gmm2.bic(X) < gmm1.bic(X)
            
            # Additional heuristic: bots are usually unimodal and tightly grouped
            if is_bimodal:
                # If means are too close, it's effectively unimodal
                means = gmm2.means_.flatten()
                if abs(means[0] - means[1]) < 10: # ms
                    is_bimodal = False
        except:
            is_bimodal = False
        
        triggered_rules = []
        if cv < 0.15: triggered_rules.append("LOW_CV_MECHANICAL")
        if std_iki < 20: triggered_rules.append("LOW_STD_SUPERHUMAN")
        if mean_iki < 30: triggered_rules.append("MEAN_BELOW_MOTOR_LIMIT")
        if kurt > 10: triggered_rules.append("HIGH_KURTOSIS_BURST")
        if not is_bimodal: triggered_rules.append("UNIMODAL_CONSISTENT")
        
        n_triggered = len(triggered_rules)
        if n_triggered >= 3:
            verdict = "BOT_CONFIRMED"
            confidence = min(0.99, 0.90 + (n_triggered * 0.02))
        elif n_triggered >= 1:
            verdict = "BOT_SUSPECTED"
            confidence = 0.60 + (n_triggered * 0.10)
        else:
            verdict = "HUMAN"
            confidence = 0.95
            
        return {
            "type": "behavioral_analysis",
            "verdict": verdict,
            "bot_probability": 0.0, # Placeholder
            "confidence": float(confidence),
            "sample_size": len(iki_ms),
            "mean_iki_ms": round(mean_iki, 2),
            "std_iki_ms": round(std_iki, 2),
            "cv": round(cv, 4),
            "is_bimodal": is_bimodal,
            "triggered_rules": triggered_rules,
            "timestamp": time.time()
        }

if __name__ == "__main__":
    logger.info("--- Running Real-Time Behavior Monitor Hardened Self-Test ---")
    
    monitor = RealtimeBehaviorMonitor({})
    
    # Test 1: Simulated Human Input (Bimodal, High Variance)
    human_iki = np.concatenate([
        np.random.normal(70, 15, 25),
        np.random.normal(200, 40, 25)
    ])
    human_timings = np.cumsum(human_iki * 1e6)
    monitor.timing_buffer.extend(human_timings)
    
    analysis = monitor.analyze_keystrokes()
    logger.info(f"[TEST] Human Simulation: Verdict={analysis['verdict']}")
    
    # Test 2: Simulated Bot Input (Unimodal, Low Variance)
    monitor.timing_buffer.clear()
    bot_iki = np.random.normal(40, 2, 50)
    bot_timings = np.cumsum(bot_iki * 1e6)
    monitor.timing_buffer.extend(bot_timings)
    
    analysis = monitor.analyze_keystrokes()
    logger.info(f"[TEST] Bot Simulation: Verdict={analysis['verdict']}, Rules={analysis['triggered_rules']}")
    
    logger.info("--- Self-Test Complete ---")
