import json
import os
import psutil
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List
import shutil
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from core.structured_logger import get_logger
logger = get_logger("dashboard")

app = FastAPI(title="ShadowNet Nexus v5.0 Health Dashboard")

# Global access to system state (to be injected from main)
SYSTEM_STATE = None

class SystemHealth(BaseModel):
    status: str
    uptime_seconds: float
    cpu_usage_percent: float
    memory_usage_mb: float
    disk_free_gb: float
    active_monitors: List[str]
    counts: Dict[str, int]
    last_heartbeat: str

@app.get("/api/health", response_model=SystemHealth)
async def get_health():
    if not SYSTEM_STATE:
        raise HTTPException(status_code=503, detail="System state not available")
    
    counts = SYSTEM_STATE.get_counts()
    if isinstance(counts, dict):
        counts_dict = counts
    else:
        counts_dict = {"detections": counts[0], "incidents": counts[1]}
    
    from core.watchdog import watchdog
    wd_monitors = [m["name"] for m in watchdog.status() if m["alive"] and not m["dead"]]
    active_m = ["process_monitor", "file_integrity_monitor"] + wd_monitors
    
    return SystemHealth(
        status="RUNNING" if SYSTEM_STATE.monitoring_active.is_set() else "STOPPED",
        uptime_seconds=time.time() - SYSTEM_STATE.start_time,
        cpu_usage_percent=psutil.cpu_percent(),
        memory_usage_mb=psutil.Process().memory_info().rss / (1024 * 1024),
        disk_free_gb=shutil.disk_usage(".").free / (1024**3),
        active_monitors=active_m,
        counts=counts_dict,
        last_heartbeat=datetime.now(timezone.utc).isoformat()
    )

@app.get("/", response_class=HTMLResponse)
async def dashboard_ui():
    return """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ShadowNet Nexus Health Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&family=JetBrains+Mono&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #00f2ff;
            --bg: #0a0b10;
            --card-bg: rgba(255, 255, 255, 0.03);
            --card-border: rgba(255, 255, 255, 0.1);
            --glass: rgba(16, 18, 27, 0.4);
            --danger: #ff3366;
            --success: #00ffcc;
        }

        body {
            background: var(--bg);
            color: #e0e0e0;
            font-family: 'Inter', sans-serif;
            margin: 0;
            overflow-x: hidden;
            background-image: 
                radial-gradient(circle at 20% 20%, rgba(0, 242, 255, 0.05) 0%, transparent 25%),
                radial-gradient(circle at 80% 80%, rgba(255, 51, 102, 0.05) 0%, transparent 25%);
            min-height: 100vh;
        }

        .dashboard {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            padding: 20px;
            background: var(--glass);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid var(--card-border);
        }

        h1 {
            font-weight: 700;
            letter-spacing: -1px;
            margin: 0;
            background: linear-gradient(90deg, #fff, var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .status-badge {
            padding: 6px 16px;
            border-radius: 30px;
            font-size: 13px;
            font-weight: 600;
            text-transform: uppercase;
            background: rgba(0, 255, 204, 0.1);
            color: var(--success);
            border: 1px solid rgba(0, 255, 204, 0.2);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .card {
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: 24px;
            padding: 24px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .card:hover {
            transform: translateY(-5px);
            border-color: var(--primary);
            box-shadow: 0 10px 30px rgba(0, 242, 255, 0.1);
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: linear-gradient(135deg, transparent 0%, rgba(0, 242, 255, 0.05) 100%);
            opacity: 0;
            transition: 0.3s;
        }

        .card:hover::before { opacity: 1; }

        .stat-label {
            font-size: 14px;
            color: #888;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            font-family: 'JetBrains Mono', monospace;
            color: #fff;
        }

        .stat-unit {
            font-size: 14px;
            color: #666;
            margin-left: 4px;
        }

        .visual-bar {
            height: 4px;
            background: #222;
            border-radius: 2px;
            margin-top: 15px;
            overflow: hidden;
        }

        .visual-fill {
            height: 100%;
            background: var(--primary);
            width: 0%;
            transition: width 1s ease-in-out;
            box-shadow: 0 0 10px var(--primary);
        }

        .monitors-list {
            margin-top: 40px;
        }

        .monitor-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px;
            background: var(--card-bg);
            margin-bottom: 10px;
            border-radius: 12px;
            border: 1px solid var(--card-border);
        }

        .monitor-name { font-weight: 600; color: #fff; }
        .monitor-status { color: var(--success); font-size: 13px; }

        .pulse {
            width: 8px;
            height: 8px;
            background: var(--success);
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
            box-shadow: 0 0 0 rgba(0, 255, 204, 0.4);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(0, 255, 204, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(0, 255, 204, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(0, 255, 204, 0); }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <header>
            <h1>ShadowNet <span style="color:var(--primary)">Nexus v5.0</span></h1>
            <div id="status-container">
                <span class="status-badge"><span class="pulse"></span>Operational</span>
            </div>
        </header>

        <div class="stats-grid">
            <div class="card">
                <div class="stat-label">Total Detections</div>
                <div class="stat-value" id="count-detect">0</div>
                <div class="visual-bar"><div class="visual-fill" id="fill-detect" style="width: 10%"></div></div>
            </div>
            <div class="card">
                <div class="stat-label">System Uptime</div>
                <div class="stat-value" id="uptime">0:00:00</div>
                <div class="stat-unit">h:m:s</div>
            </div>
            <div class="card">
                <div class="stat-label">Memory Impact</div>
                <div class="stat-value" id="ram">0.0</div>
                <div class="stat-unit">MB</div>
                <div class="visual-bar"><div class="visual-fill" id="fill-ram" style="width: 20%"></div></div>
            </div>
            <div class="card">
                <div class="stat-label">CPU Pressure</div>
                <div class="stat-value" id="cpu">0</div>
                <div class="stat-unit">%</div>
                <div class="visual-bar"><div class="visual-fill" id="fill-cpu"></div></div>
            </div>
        </div>

        <div class="monitors-list">
            <h2 style="margin-bottom: 20px; color: #888; font-size: 16px; text-transform: uppercase;">Active Sub-Systems</h2>
            <div id="monitors-container">
                <!-- Loaded via JS -->
            </div>
        </div>
    </div>

    <script>
        async function updateDashboard() {
            try {
                const response = await fetch('/api/health');
                const data = await response.json();

                document.getElementById('count-detect').innerText = data.counts.detections || 0;
                document.getElementById('cpu').innerText = data.cpu_usage_percent.toFixed(1);
                document.getElementById('fill-cpu').style.width = data.cpu_usage_percent + '%';
                
                document.getElementById('ram').innerText = data.memory_usage_mb.toFixed(1);
                document.getElementById('fill-ram').style.width = Math.min((data.memory_usage_mb / 512) * 100, 100) + '%';
                
                const uptime = data.uptime_seconds;
                const h = Math.floor(uptime / 3600);
                const m = Math.floor((uptime % 3600) / 60);
                const s = Math.floor(uptime % 60);
                document.getElementById('uptime').innerText = `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;

                const mContainer = document.getElementById('monitors-container');
                mContainer.innerHTML = data.active_monitors.map(m => `
                    <div class="monitor-row">
                        <span class="monitor-name">${m.replace('_', ' ').toUpperCase()}</span>
                        <span class="monitor-status">ACTIVE</span>
                    </div>
                `).join('');

            } catch (err) {
                console.error("Failed to update dashboard:", err);
            }
        }

        setInterval(updateDashboard, 2000);
        updateDashboard();
    </script>
</body>
</html>
    """

def start_dashboard(state, host="127.0.0.1", port=8000):
    global SYSTEM_STATE
    SYSTEM_STATE = state
    logger.info(f"Starting Health Dashboard on http://{host}:{port}")
    config = uvicorn.Config(app, host=host, port=port, log_level="warning")
    server = uvicorn.Server(config)
    threading.Thread(target=server.run, daemon=True).start()

if __name__ == "__main__":
    # Mock state for standalone testing
    class MockState:
        def __init__(self):
            self.monitoring_active = threading.Event()
            self.monitoring_active.set()
            self.start_time = time.time()
        def get_counts(self):
            return {"detections": 12, "incidents": 4}
            
    start_dashboard(MockState())
    print("Dashboard mock running at http://127.0.0.1:8000")
    while True: time.sleep(1)
