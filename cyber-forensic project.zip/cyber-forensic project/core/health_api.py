from http.server import HTTPServer, BaseHTTPRequestHandler
import json, threading, time
from datetime import datetime, timezone
from core.structured_logger import get_logger

logger = get_logger("health_api")

class HealthHandler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass  # suppress access logs

    def do_GET(self):
        try:
            if self.path == "/health":
                data = self._build_health()
                code = 200 if data["status"] == "HEALTHY" else 503
            elif self.path == "/metrics":
                from core.performance_monitor import perf
                data = {"metrics": perf.all_stats()}
                code = 200
            elif self.path == "/threads":
                from core.watchdog import watchdog
                data = {"threads": watchdog.status()}
                code = 200
            elif self.path == "/evidence":
                data = self._build_evidence_summary()
                code = 200
            else:
                data = {"error": "not found"}
                code = 404

            body = json.dumps(data, indent=2, default=str).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            logger.error(f"Health API Error: {e}")
            self.send_error(500, str(e))

    def _build_health(self) -> dict:
        from core.watchdog import watchdog
        from core.performance_monitor import perf
        threads = watchdog.status()
        dead = [t for t in threads if t["dead"]]
        breaching = perf.breaching_thresholds()
        
        status = "HEALTHY"
        if dead: 
            status = "DEGRADED"
        if len(dead) > 2: 
            status = "CRITICAL"
        
        return {
            "status": status,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "uptime_seconds": _uptime_seconds(),
            "dead_threads": dead,
            "performance_breaching": breaching,
            "version": "5.0"
        }

    def _build_evidence_summary(self) -> dict:
        from pathlib import Path
        vault = Path("evidence")
        total = 0
        if vault.exists():
            total = sum(f.stat().st_size for f in vault.rglob("*") if f.is_file())
            
        return {
            "vault_size_mb": round(total / 1024 / 1024, 2),
            "snapshots": len(list((vault / "emergency_snapshots").glob("SNAP-*")))
                         if (vault / "emergency_snapshots").exists() else 0,
            "incidents": len(list((vault / "incidents").glob("INC-*")))
                         if (vault / "incidents").exists() else 0,
            "reports": len(list((vault / "reports").glob("*.json")))
                       if (vault / "reports").exists() else 0,
        }

_start_time = datetime.now(timezone.utc)

def _uptime_seconds() -> float:
    return (datetime.now(timezone.utc) - _start_time).total_seconds()

def start_health_api(port: int = 8765):
    try:
        server = HTTPServer(("127.0.0.1", port), HealthHandler)
        thread = threading.Thread(
            target=server.serve_forever, daemon=True, name="HealthAPI"
        )
        thread.start()
        logger.info(f"Health API started on http://127.0.0.1:{port}", extra={"event": "API_START"})
        return thread
    except Exception as e:
        logger.error(f"Failed to start Health API: {e}")
        return None
