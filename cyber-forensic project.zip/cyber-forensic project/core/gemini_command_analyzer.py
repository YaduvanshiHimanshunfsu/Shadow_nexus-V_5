import google.generativeai as genai
import json
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional
from collections import deque

from utils.model_selector import model_selector
from core.structured_logger import get_logger

logger = get_logger("gemini_analyzer")

import threading

class RateLimiter:
    """Enforces API quota limits (max calls per window) - thread-safe."""
    def __init__(self, max_calls: int, window_seconds: int):
        self.max_calls = max_calls
        self.window = timedelta(seconds=window_seconds)
        self.calls = deque()
        self._lock = threading.Lock()
    
    def allow_call(self) -> bool:
        now = datetime.now(timezone.utc)
        with self._lock:
            while self.calls and now - self.calls[0] > self.window:
                self.calls.popleft()
            if len(self.calls) < self.max_calls:
                self.calls.append(now)
                return True
        return False

class CircuitBreaker:
    """Prevents spamming the API if it's down or failing."""
    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 300):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = timedelta(seconds=recovery_timeout)
        self.failures = 0
        self.last_failure_time = None
        self.state = "CLOSED" # CLOSED, OPEN, HALF-OPEN
        self._lock = threading.Lock()

    def allow_request(self) -> bool:
        with self._lock:
            if self.state == "OPEN":
                if datetime.now(timezone.utc) - self.last_failure_time > self.recovery_timeout:
                    self.state = "HALF-OPEN"
                    return True
                return False
            return True

    def record_failure(self):
        with self._lock:
            self.failures += 1
            self.last_failure_time = datetime.now(timezone.utc)
            if self.failures >= self.failure_threshold:
                self.state = "OPEN"
                logger.error("Gemini API Circuit Breaker OPENED due to high failure rate.")

    def record_success(self):
        with self._lock:
            self.failures = 0
            self.state = "CLOSED"

class GeminiCommandAnalyzer:
    """
    Use Gemini to analyze if command is anti-forensics activity
    Understands CONTEXT and INTENT, not just keyword matching
    """
    
    def __init__(self, api_key: str, model_name: str = 'gemini-2.5-flash', suspicious_keywords: List[str] = None):
        """
        Initialize Gemini Command Analyzer
        
        Args:
            api_key: Gemini API key
            model_name: Model to use (flash for speed, pro for accuracy)
            suspicious_keywords: Keywords for fallback matching
        """
        from utils.cache_manager import CacheManager
        
        self.api_key = api_key
        genai.configure(api_key=self.api_key)
        self.model_name = model_selector.validate_model(model_name)
        self.model = genai.GenerativeModel(self.model_name)
        self.suspicious_keywords = suspicious_keywords or []
        self.rate_limiter = RateLimiter(20, 60) # Default to 20 RPM
        self.circuit_breaker = CircuitBreaker()
        self.cache = CacheManager(cache_dir="./cache/commands", ttl_seconds=3600*24)
    
    def _keyword_fallback(self, command_line: str, error_msg: str, process_info: Dict[str, Any] = None) -> Dict[str, Any]:
        """Simple keyword-based detection fallback with V5 structural anomaly preservation"""
        cmd_lower = command_line.lower()
        
        # Check if it's a V5 structural anomaly (NTFS, Entropy, etc.)
        is_v5_anomaly = False
        if process_info and process_info.get('name') == 'KERNEL_SPACE':
            is_v5_anomaly = True
            
        is_suspicious = is_v5_anomaly or any(kw.lower() in cmd_lower for kw in self.suspicious_keywords)
        
        return {
            'is_anti_forensics': is_suspicious,
            'confidence': 0.9 if is_v5_anomaly else (0.6 if is_suspicious else 0.0),
            'category': 'system_anomaly' if is_v5_anomaly else 'keyword_fallback',
            'severity': 'HIGH' if is_suspicious else 'LOW',
            'explanation': f'API unavailable/rate-limited/circuit-open. Keyword fallback used (V5 Anomaly: {is_v5_anomaly}). Error: {error_msg}',
            'threat_indicators': ['structural_anomaly'] if is_v5_anomaly else (['keyword_match_fallback'] if is_suspicious else []),
            'recommended_action': 'immediate_investigation' if is_v5_anomaly else ('review_manually' if is_suspicious else 'ignore'),
            'likely_threat_actor': 'Unknown',
            'context_notes': f'Circuit breaker state: {self.circuit_breaker.state}',
            'mitre_attack_ttps': [],
            'analysis_timestamp': datetime.now(timezone.utc).isoformat(),
            'model_used': 'KEYWORD_ENGINE',
            'command_analyzed': command_line,
            'fallback_mode': True,
            'error': error_msg
        }

    def analyze_command(self, command_line: str, process_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        Use Gemini to analyze if command is anti-forensics activity
        """
        from utils.command_decoder import CommandDecoder, command_history
        from prompts.enhanced_prompts import IMPROVED_COMMAND_ANALYSIS_PROMPT
        
        # 1. Circuit Breaker Check
        if not self.circuit_breaker.allow_request():
            return self._keyword_fallback(command_line, "Gemini API Circuit Breaker is OPEN", process_info)

        # 2. Rate Limiting Check
        if not self.rate_limiter.allow_call():
            return self._keyword_fallback(command_line, "Rate limit exceeded (local)", process_info)

        # Decode if obfuscated
        decoded_command, obfuscation_techniques = CommandDecoder.decode_if_encoded(command_line)
        
        # Check for renamed binary
        is_renamed = CommandDecoder.detect_renamed_binary(
            process_info.get('name', ''),
            command_line
        )
        
        # Add to command history
        user = process_info.get('user', 'Unknown')
        command_history.add_command(user, command_line, process_info)
        
        # 3. Cache Check
        cache_key = self.cache.generate_cache_key(decoded_command, is_renamed, user)
        cached = self.cache.get_cached_response(cache_key)
        if cached:
            logger.info(f"Cache HIT for command: {decoded_command[:30]}...", extra={"event": "CACHE_HIT"})
            return cached
        
        # Build enhanced prompt
        prompt = IMPROVED_COMMAND_ANALYSIS_PROMPT.format(
            command_line=decoded_command,
            process_name=process_info.get('name', 'Unknown'),
            pid=process_info.get('pid', 'N/A'),
            parent_name=process_info.get('parent_name', 'Unknown'),
            parent_pid=process_info.get('parent_pid', 'N/A'),
            user=user,
            timestamp=process_info.get('timestamp', datetime.now(timezone.utc).isoformat()),
            cwd=process_info.get('cwd', 'Unknown'),
            is_elevated='YES' if process_info.get('elevated') else 'NO'
        )
        
        try:
            response = self.model.generate_content(prompt, request_options={"timeout": 10})
            response_text = response.text.strip()
            
            # Clean JSON formatting
            if '```json' in response_text:
                response_text = response_text.split('```json')[1].split('```')[0]
            elif '```' in response_text:
                response_text = response_text.split('```')[1].split('```')[0]
            
            result = json.loads(response_text.strip())
            
            required = ['is_anti_forensics', 'confidence', 'category', 'severity']
            if not all(k in result for k in required):
                raise ValueError(f"Missing required fields: {[k for k in required if k not in result]}")
            
            if not isinstance(result['confidence'], (int, float)):
                result['confidence'] = 0.5 # Safety default
            
            # Meta-info
            result['analysis_timestamp'] = datetime.now(timezone.utc).isoformat()
            result['model_used'] = self.model_name
            result['command_analyzed'] = command_line
            result['decoded_command'] = decoded_command if decoded_command != command_line else None
            result['obfuscation_detected'] = obfuscation_techniques
            result['renamed_binary_suspected'] = is_renamed
            
            # Cache the results
            self.cache.cache_response(cache_key, result)
            self.circuit_breaker.record_success()
            
            return result
            
        except Exception as e:
            logger.error(f"Gemini Analysis Failed: {e}")
            self.circuit_breaker.record_failure()
            return self._keyword_fallback(command_line, str(e), process_info)
    
    def batch_analyze_commands(self, commands: list) -> list:
        """
        Analyze multiple commands in a single API call
        """
        if not commands:
            return []
        
        if not self.rate_limiter.allow_call():
            return [self._keyword_fallback(cmd, "Rate limit exceeded") for cmd, info in commands]

        commands_text = "\n\n".join([
            f"COMMAND {i+1}:\n{cmd}\nPROCESS INFO: {json.dumps(info)}"
            for i, (cmd, info) in enumerate(commands)
        ])
        
        prompt = f"Analyze these {len(commands)} commands for anti-forensics activity. Respond with a JSON array of objects.\n\n{commands_text}"
        
        try:
            response = self.model.generate_content(prompt, request_options={"timeout": 15})
            response_text = response.text.strip()
            if '```json' in response_text:
                response_text = response_text.split('```json')[1].split('```')[0]
            results = json.loads(response_text.strip())
            return results
        except Exception as e:
            logger.warning(f"Batch Analysis Failed: {e}. Falling back to individual.")
            return [self.analyze_command(cmd, info) for cmd, info in commands]
