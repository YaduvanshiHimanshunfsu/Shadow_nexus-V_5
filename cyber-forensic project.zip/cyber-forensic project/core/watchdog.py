import threading, time, logging
from typing import Callable
from core.structured_logger import get_logger

logger = get_logger("watchdog")

class ThreadWatchdog:
    def __init__(self, check_interval: float = 5.0):
        self.check_interval = check_interval
        self._registry: dict[str, dict] = {}
        self._lock = threading.Lock()
        self._running = False
        self._thread: threading.Thread | None = None

    def register(self, name: str, factory: Callable,
                 heartbeat_timeout: float = 30.0,
                 max_restarts: int = 10):
        """Register a module factory. The watchdog starts the thread."""
        thread = factory()
        if thread.ident is None:
            thread.start()
            
        with self._lock:
            self._registry[name] = {
                "factory": factory,
                "thread": thread,
                "last_heartbeat": time.monotonic(),
                "last_restart_time": 0.0,  # Use 0 so first restart is never treated as a crash-loop
                "heartbeat_timeout": heartbeat_timeout,
                "restarts": 0,
                "max_restarts": max_restarts,
                "dead": False,
            }

    def heartbeat(self, name: str):
        with self._lock:
            if name in self._registry:
                self._registry[name]["last_heartbeat"] = time.monotonic()

    def start(self):
        self._running = True
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="Watchdog"
        )
        self._thread.start()

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            time.sleep(self.check_interval)
            now = time.monotonic()
            with self._lock:
                items = list(self._registry.items())
            
            for name, info in items:
                if info["dead"]:
                    continue
                    
                is_alive = info["thread"].is_alive()
                timed_out = (now - info["last_heartbeat"]) > info["heartbeat_timeout"]
                
                if not is_alive or timed_out:
                    reason = "dead" if not is_alive else "heartbeat_timeout"
                    
                    if info["restarts"] >= info["max_restarts"]:
                        logger.critical(f"Thread '{name}' hit max restarts. Giving up.",
                            extra={"event": "WATCHDOG_GIVE_UP", "data": {"name": name}})
                        with self._lock:
                            self._registry[name]["dead"] = True
                        continue
                        
                    logger.error(f"Thread '{name}' failed ({reason}). Restarting...",
                        extra={"event": "WATCHDOG_RESTART", "data": {
                            "name": name, "reason": reason,
                            "attempt": info["restarts"] + 1
                        }})
                        
                    try:
                        # Calculate backoff multiplier
                        time_since_last_restart = now - info.get("last_restart_time", 0.0)
                        penalty = 0
                        if time_since_last_restart < 10.0 and info["restarts"] > 0:
                            # Thread died almost immediately after restart — crash-looping
                            penalty = 2
                            logger.warning(f"Watchdog: '{name}' crash-looping. Increasing backoff penalty.")
                            
                        effective_restarts = info["restarts"] + penalty
                        backoff = min(2 ** effective_restarts, 120)  # Max 2 minutes
                        logger.info(f"Watchdog: backing off {backoff}s before restarting '{name}'", 
                                     extra={"event": "WATCHDOG_BACKOFF"})
                        time.sleep(backoff)

                        # Cleanly generate and start the new thread
                        new_thread = info["factory"]()
                        if new_thread.ident is None:
                            new_thread.start()
                            
                        with self._lock:
                            self._registry[name]["thread"] = new_thread
                            self._registry[name]["last_heartbeat"] = time.monotonic()
                            self._registry[name]["last_restart_time"] = time.monotonic()
                            # Increment by 1 + penalty (not double-counting)
                            self._registry[name]["restarts"] += 1 + penalty
                            
                        logger.info(f"Thread '{name}' restarted successfully.",
                            extra={"event": "WATCHDOG_RESTARTED", "data": {"name": name}})
                            
                    except RuntimeError as e:
                        logger.error(f"Failed to restart '{name}' (Thread State Error): {e}", extra={"event": "WATCHDOG_ERROR"})
                    except Exception as e:
                        logger.error(f"Failed to restart '{name}': {e}", extra={"event": "WATCHDOG_ERROR"})

    def status(self) -> list[dict]:
        with self._lock:
            return [
                {
                    "name": name,
                    "alive": info["thread"].is_alive(),
                    "restarts": info["restarts"],
                    "dead": info["dead"],
                    "last_heartbeat_ago_s": round(
                        time.monotonic() - info["last_heartbeat"], 1
                    )
                }
                for name, info in self._registry.items()
            ]

watchdog = ThreadWatchdog(check_interval=5.0)
