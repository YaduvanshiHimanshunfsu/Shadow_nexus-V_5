import os, platform
from pathlib import Path
from core.structured_logger import get_logger

logger = get_logger("secure_config")

class SecureConfigManager:
    """
    Loads configuration with secrets from secure sources.
    """

    def get_api_key(self, key_name: str) -> str:
        if platform.system() == "Windows":
            return self._get_from_credential_manager(key_name)
        else:
            return self._get_from_env_or_file(key_name)

    def _get_from_credential_manager(self, key_name: str) -> str:
        try:
            import keyring
            value = keyring.get_password("ShadowNetNexus", key_name)
            if value:
                return value
        except ImportError:
            logger.warning("keyring library not installed. Falling back to environment variables.")
        except Exception as e:
            logger.error(f"Credential manager error: {e}")
            
        # Fallback to env
        return self._get_from_env_or_file(key_name)

    def _get_from_env_or_file(self, key_name: str) -> str:
        value = os.getenv(key_name)
        if value:
            return value
            
        # Try /etc/shadownet/secrets (root-only readable) on Linux
        if platform.system() != "Windows":
            secrets_path = Path("/etc/shadownet/secrets")
            if secrets_path.exists():
                try:
                    # Verify 0600 permissions
                    mode = oct(secrets_path.stat().st_mode)[-3:]
                    if mode != "600":
                        logger.warning(f"Secrets file {secrets_path} has insecure permissions {mode}. Must be 600.")
                        
                    for line in secrets_path.read_text().splitlines():
                        if line.startswith(f"{key_name}="):
                            return line.split("=", 1)[1].strip()
                except Exception as e:
                    logger.error(f"Error reading secrets file: {e}")
                    
        return ""

    def store_api_key(self, key_name: str, value: str):
        """Interactive: store a secret in the platform credential store."""
        if platform.system() == "Windows":
            try:
                import keyring
                keyring.set_password("ShadowNetNexus", key_name, value)
                logger.info(f"Stored '{key_name}' in Windows Credential Manager")
            except ImportError:
                print("Error: keyring library not installed. Use 'pip install keyring'.")
        else:
            secrets_path = Path("/etc/shadownet/secrets")
            try:
                secrets_path.parent.mkdir(parents=True, exist_ok=True)
                lines = []
                if secrets_path.exists():
                    lines = secrets_path.read_text().splitlines()
                lines = [l for l in lines if not l.startswith(f"{key_name}=")]
                lines.append(f"{key_name}={value}")
                secrets_path.write_text("\n".join(lines) + "\n")
                os.chmod(secrets_path, 0o600)
                logger.info(f"Stored '{key_name}' in {secrets_path} (chmod 600)")
            except Exception as e:
                logger.error(f"Failed to store secret: {e}")

# Global singleton
secure_config = SecureConfigManager()
