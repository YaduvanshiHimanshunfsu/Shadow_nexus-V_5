import os
import json
import time
import logging
import threading
from pathlib import Path
from datetime import datetime, timezone
import google.generativeai as genai
from typing import Dict, List, Any, Optional
from queue import Queue

from core.structured_logger import get_logger
from core.performance_monitor import timed, perf

logger = get_logger("narrative_engine")

class ForensicNarrativeEngine(threading.Thread):
    """
    Synthesizes findings from all forensic modules into a unified narrative.
    Powered by gemini-2.5-flash for real-time reporting.
    """
    
    def __init__(self, config: Dict[str, Any], api_key: Optional[str] = None):
        super().__init__(daemon=True, name="NarrativeEngine")
        self.config = config.get('shadownet_v5', {}).get('forensic_narrative', {})
        self.api_key = api_key or os.getenv('GEMINI_API_KEY')
        self.enabled = self.config.get('enabled', True)
        self.interval = self.config.get('synthesis_interval_seconds', 60)
        self.min_findings = self.config.get('min_findings_for_synthesis', 1)
        self.output_dir = Path(self.config.get('output_dir', 'evidence/reports'))
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Queues for findings from other modules
        self.ntfs_queue = Queue()
        self.entropy_queue = Queue()
        self.behavior_queue = Queue()
        self.process_queue = Queue()
        
        self.running = False
        if self.api_key:
            genai.configure(api_key=self.api_key)
            self.model = genai.GenerativeModel('gemini-2.5-flash')
            from utils.cache_manager import CacheManager
            self.cache = CacheManager(cache_dir="./cache/narratives", ttl_seconds=3600*6) # 6 hour cache
        else:
            self.enabled = False
            logger.warning("No API key for Narrative Engine. Disabled.", extra={"event": "DISABLED_NO_KEY"})

    def _call_gemini_with_backoff(self, prompt: str) -> Optional[str]:
        # Implementation remains same for now but could use cache too
        import time as _time
        base_delay = 2.0
        max_delay = 64.0
        for attempt in range(6):
            try:
                with timed(perf, "gemini_api_call_ms"):
                    response = self.model.generate_content(prompt, request_options={"timeout": 15})
                return response.text
            except Exception as e:
                err = str(e)
                if "429" in err or "quota" in err.lower():
                    delay = min(base_delay * (2 ** attempt), max_delay)
                    logger.warning(
 f"Gemini rate limited (attempt {attempt+1}), retry in {delay:.0f}s",
                        extra={"event": "GEMINI_RATE_LIMIT"})
                    _time.sleep(delay)
                else:
                    logger.error(f"Gemini error (attempt {attempt+1}): {e}",
                        extra={"event": "GEMINI_ERROR"})
                    if attempt < 5:
                        _time.sleep(base_delay * (2 ** attempt))
                    else:
                        return None
        return None

    def _build_prompt(self, ntfs, entropy, behavior, process) -> str:
        from prompts.enhanced_prompts import FORENSIC_NARRATIVE_PROMPT
        return FORENSIC_NARRATIVE_PROMPT.format(
            ntfs=json.dumps(ntfs, indent=2, default=str),
            entropy=json.dumps(entropy, indent=2, default=str),
            behavior=json.dumps(behavior, indent=2, default=str),
            process=json.dumps(process, indent=2, default=str)
        )

    def _save_report(self, report: Dict):
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        json_path = self.output_dir / f"forensic_narrative_{ts}.json"
        md_path   = self.output_dir / f"forensic_narrative_{ts}.md"

        with open(json_path, 'w') as f:
            json.dump(report, f, indent=2, default=str)

        lines = [
            f"# Forensic Narrative — {ts}",
            f"",
            f"## Overall Confidence: {report.get('overall_confidence', 'N/A')}",
            f"**Reasoning:** {report.get('confidence_reasoning', '')}",
            f"",
            f"## Forensic Narrative",
            report.get('forensic_narrative', 'No narrative generated.'),
            f"",
            f"## Timeline",
        ]
        for e in report.get('timeline', []):
            lines.append(
                f"- **{e.get('time','?')}** | "
                f"`{e.get('mitre_ttp','?')}` | "
                f"{e.get('event','')}")

        lines += ["", "## MITRE ATT&CK TTPs"]
        for t in report.get('mitre_ttps', []):
            lines.append(
                f"- **{t.get('ttp_id')}** {t.get('technique')} "
                f"(confidence: {t.get('confidence','?')})")
            for ev in t.get('evidence', []):
                lines.append(f"  - {ev}")

        lines += ["", "## Corroboration Map"]
        for c in report.get('corroboration_map', []):
            lines.append(
                f"- {c.get('attacker_action')} confirmed by: "
                f"{', '.join(c.get('confirmed_by', []))}")

        lines += ["", "## Artifact Gaps (Evidence Destroyed)"]
        for g in report.get('artifact_gaps', []):
            lines.append(f"- {g}")

        lines += ["", "## Recommended Additional Evidence"]
        for r in report.get('recommended_evidence', []):
            lines.append(f"- {r}")

        with open(md_path, 'w') as f:
            f.write("\n".join(lines))

        logger.info(f"Narrative saved: {json_path.name}",
            extra={"event": "NARRATIVE_SAVED",
                   "data": {"json": str(json_path), "md": str(md_path)}})

    def run(self):
        if not self.enabled: return
        self.running = True
        logger.info("Forensic Narrative Engine active.", extra={"event": "MODULE_START"})
        
        while self.running:
            # Collect findings
            ntfs = []
            while not self.ntfs_queue.empty(): ntfs.append(self.ntfs_queue.get())
            entropy = []
            while not self.entropy_queue.empty(): entropy.append(self.entropy_queue.get())
            behavior = []
            while not self.behavior_queue.empty(): behavior.append(self.behavior_queue.get())
            process = []
            while not self.process_queue.empty(): process.append(self.process_queue.get())
            
            total = len(ntfs) + len(entropy) + len(behavior) + len(process)
            
            if total >= self.min_findings:
                # FIX 9: Truncate findings and log
                MAX_FINDINGS = 50
                if len(ntfs) > MAX_FINDINGS:
                    logger.warning(f"Truncated NTFS findings from {len(ntfs)} to {MAX_FINDINGS}", 
                                 extra={"event": "PROMPT_TRUNCATED"})
                    ntfs = ntfs[-MAX_FINDINGS:]
                if len(entropy) > MAX_FINDINGS:
                    logger.warning(f"Truncated Entropy findings from {len(entropy)} to {MAX_FINDINGS}", 
                                 extra={"event": "PROMPT_TRUNCATED"})
                    entropy = entropy[-MAX_FINDINGS:]
                if len(behavior) > MAX_FINDINGS:
                    logger.warning(f"Truncated Behavior findings from {len(behavior)} to {MAX_FINDINGS}", 
                                 extra={"event": "PROMPT_TRUNCATED"})
                    behavior = behavior[-MAX_FINDINGS:]
                if len(process) > MAX_FINDINGS:
                    logger.warning(f"Truncated Process findings from {len(process)} to {MAX_FINDINGS}", 
                                 extra={"event": "PROMPT_TRUNCATED"})
                    process = process[-MAX_FINDINGS:]

                prompt = self._build_prompt(ntfs, entropy, behavior, process)
                
                # Cache Check
                cache_key = self.cache.generate_cache_key(prompt)
                cached_report = self.cache.get_cached_response(cache_key)
                
                report_json = None
                if cached_report:
                    logger.info("Narrative cache HIT", extra={"event": "CACHE_HIT"})
                    report_json = cached_report
                else:
                    text = self._call_gemini_with_backoff(prompt)
                    if text:
                        try:
                            import re
                            match = re.search(r'\{.*\}', text, re.DOTALL)
                            if match:
                                report_json = json.loads(match.group())
                                # Cache the new narrative
                                self.cache.cache_response(cache_key, report_json)
                            else:
                                logger.warning("No JSON found in response", extra={"event": "NO_JSON"})
                        except json.JSONDecodeError as e:
                            logger.warning(f"JSON parse failed: {e}", extra={"event": "JSON_PARSE_ERROR"})
                
                if not report_json:
                    logger.warning("Synthesis failing/failed. Using Rule-Based Fallback.", extra={"event": "FALLBACK_ACTIVE"})
                    report_json = self._rule_based_fallback_synthesis(ntfs, entropy, behavior, process)
                
                if report_json:
                    self._save_report(report_json)
            
            time.sleep(self.interval)

    def _rule_based_fallback_synthesis(self, ntfs: List, entropy: List, behavior: List, process: List) -> Dict:
        """Generates a structured forensic report without AI help"""
        timeline = []
        ttps = []
        
        # Simple timeline generation
        for p in process:
            timeline.append({
                "time": p.get('timestamp', datetime.now(timezone.utc).isoformat()),
                "event": f"Process Execution: {p.get('command')}",
                "source_artifacts": ["process_monitor"],
                "mitre_ttp": p.get('mitre_ttp', 'T1059')
            })
            
        for b in behavior:
            timeline.append({
                "time": datetime.now(timezone.utc).isoformat(),
                "event": f"Behavioral Anomaly: {b.get('verdict')}",
                "source_artifacts": ["behavior_monitor"],
                "mitre_ttp": "T1056.001"
            })

        for n in ntfs:
            timeline.append({
                "time": datetime.now(timezone.utc).isoformat(),
                "event": f"NTFS Anomaly: {n.get('type')}",
                "source_artifacts": ["ntfs_parser"],
                "mitre_ttp": "T1070.006"
            })

        # Summary
        return {
            "timeline": sorted(timeline, key=lambda x: x['time']),
            "mitre_ttps": [
                {"ttp_id": "T1070.006", "technique": "Timestomping", "evidence": ["NTFS Discrepancy"], "confidence": 0.7 if ntfs else 0.0},
                {"ttp_id": "T1056.001", "technique": "Keylogging/Input", "evidence": ["Behavioral Anomalies"], "confidence": 0.8 if behavior else 0.0},
                {"ttp_id": "T1059", "technique": "Command Execution", "evidence": ["Process Alerts"], "confidence": 0.9 if process else 0.0}
            ],
            "corroboration_map": [],
            "overall_confidence": 0.65,
            "confidence_reasoning": "Rule-based fallback synthesis due to Gemini API unavailability.",
            "artifact_gaps": ["Unable to infer gaps without semantic analysis"],
            "forensic_narrative": f"CRITICAL: Gemini API is unresponsive. Local rule-based synthesis active. Total findings processed: {len(ntfs)+len(entropy)+len(behavior)+len(process)}.",
            "recommended_evidence": ["Manual review of raw logs", "Snapshot inspection"]
        }

    def stop(self):
        self.running = False
