"""
ShadowNet Nexus v5.0 — Evidence Chain

NOVELTY CLAIM (Q1 2026):
No system in existence — commercial or open-source — performs all of 
the following simultaneously on a LIVE running system:
  - Raw $MFT/$USN/$LogFile binary parsing without disk imaging
  - Cluster-level entropy mapping with K-S uniformity testing
  - Wipe pattern signature detection in slack space
  - Real OS-level input hook keystroke dynamics classification
  - LLM forensic narrative synthesis across all artifact streams

This module ensures cryptographic integrity of all collected evidence by:
  1. Generating a SHA-256 / MD5 manifest for every evidence snapshot.
  2. Requesting an RFC 3161 trusted timestamp from a public TSA (DigiCert,
     Sectigo, Starfield, or FreeTSA) — proving the evidence existed at a
     specific point in time with a third-party cryptographic signature.
  3. Verifying the manifest and timestamp at system startup.
"""

import hashlib
import json
import os
import platform
import subprocess
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Any, List

from core.performance_monitor import perf, timed
from core.structured_logger import get_logger
logger = get_logger("evidence_chain")

def generate_manifest(snapshot_dir: Path) -> Dict[str, Any]:
    """
    Generates a SHA-256 manifest of every file in the snapshot directory.
    Follows RFC 3227 and NIST SP 800-86 standards for evidence handling.
    """
    with timed(perf, "manifest_generation_ms"):
        manifest = {
            "manifest_version": "1.0",
            "standard": "RFC 3227 / NIST SP 800-86",
            "snapshot_id": snapshot_dir.name,
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "generator": "ShadowNet Nexus v5.0 Evidence Chain",
            "files": {}
        }

        # Iterate through all files in the snapshot directory
        for f in sorted(snapshot_dir.rglob("*")):
            if f.is_file() and f.name != "manifest.json":
                try:
                    data = f.read_bytes()
                    manifest["files"][str(f.relative_to(snapshot_dir))] = {
                        "sha256": hashlib.sha256(data).hexdigest(),
                        "md5": hashlib.md5(data).hexdigest(),
                        "size_bytes": len(data),
                        "modified_utc": datetime.fromtimestamp(
                            f.stat().st_mtime, tz=timezone.utc
                        ).isoformat()
                    }
                except Exception as e:
                    print(f"[EvidenceChain] Error hashing file {f}: {e}")

    manifest_path = snapshot_dir / "manifest.json"
    tsr_path = snapshot_dir / "manifest.tsr"
    try:
        manifest_path.write_text(json.dumps(manifest, indent=2))

        # ── RFC 3161 Trusted Timestamp ────────────────────────────────────────
        # Uses our self-contained DER encoder — no extra pip packages needed.
        # Tries DigiCert → Sectigo → Starfield → FreeTSA in priority order.
        try:
            from core.rfc3161_timestamper import request_timestamp
            manifest_bytes = manifest_path.read_bytes()
            ts_result = request_timestamp(manifest_bytes, tsr_path, timeout=12)
            if ts_result["success"]:
                manifest["rfc3161_timestamp"] = {
                    "tsa_used":       ts_result["tsa_used"],
                    "status":         ts_result["status_text"],
                    "hash_hex":       ts_result["hash_hex"],
                    "tsr_file":       tsr_path.name,
                    "timestamp_utc":  ts_result["timestamp_utc"],
                }
                # Rewrite manifest with timestamp metadata included
                manifest_path.write_text(json.dumps(manifest, indent=2))
            else:
                logger.warning(
                    f"RFC 3161 timestamp non-fatal failure: {ts_result.get('reason')}. "
                    "SHA-256 manifest remains valid.",
                    extra={"event": "TSA_TIMESTAMP_FAILED"}
                )
        except Exception as e:
            logger.warning(
                f"RFC 3161 timestamping raised an exception (non-fatal): {e}",
                extra={"event": "TSA_TIMESTAMP_FAILED"}
            )

        # ── Make manifest read-only ───────────────────────────────────────────
        if platform.system() == "Windows":
            subprocess.run(["attrib", "+R", str(manifest_path)], capture_output=True, check=False)
        else:
            manifest_path.chmod(0o444)

    except Exception as e:
        logger.error(f"Error writing manifest: {e}")

    return manifest

def verify_manifest(snapshot_dir: Path) -> Dict[str, Any]:
    """
    Re-hashes all files and compares them against the stored manifest.
    Also verifies the RFC 3161 .tsr file if present.
    Detects tampering or data corruption.
    """
    manifest_path = snapshot_dir / "manifest.json"
    tsr_path      = snapshot_dir / "manifest.tsr"

    if not manifest_path.exists():
        return {"status": "NO_MANIFEST", "tampered_files": []}
    
    try:
        manifest = json.loads(manifest_path.read_text())
        tampered = []
        
        for rel_path, meta in manifest.get("files", {}).items():
            f = snapshot_dir / rel_path
            if not f.exists():
                tampered.append(f"{rel_path} (MISSING)")
                continue
            try:
                actual_sha256 = hashlib.sha256(f.read_bytes()).hexdigest()
                if actual_sha256 != meta.get("sha256"):
                    tampered.append(f"{rel_path} (HASH_MISMATCH)")
            except Exception as e:
                tampered.append(f"{rel_path} (READ_ERROR: {e})")

        # ── RFC 3161 .tsr structural verification ─────────────────────────────
        tsr_status = None
        if tsr_path.exists():
            try:
                from core.rfc3161_timestamper import verify_timestamp
                # We verify against the manifest content at time of generation.
                # The manifest bytes when the TSR was created are stored as-is;
                # any post-hoc modification would invalidate the hash inside the TSR.
                manifest_bytes = manifest_path.read_bytes()
                tsr_status = verify_timestamp(tsr_path, manifest_bytes)
            except Exception as e:
                tsr_status = {"valid": False, "reason": str(e)}
        else:
            tsr_status = {"valid": False, "reason": "No .tsr file found (timestamp not obtained)"}

        return {
            "status": "TAMPERED" if tampered else "INTACT",
            "tampered_files": tampered,
            "verified_at_utc": datetime.now(timezone.utc).isoformat(),
            "rfc3161_tsr_check": tsr_status,
        }
    except Exception as e:
        return {"status": "VERIFICATION_ERROR", "error": str(e)}

if __name__ == "__main__":
    import tempfile
    import shutil
    
    print("--- Running Evidence Chain Self-Test ---")
    
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)
        
        # 1. Create synthetic evidence
        file1 = tmp_path / "evidence1.txt"
        file1.write_text("Integrity is everything.")
        
        subdir = tmp_path / "logs"
        subdir.mkdir()
        file2 = subdir / "system.log"
        file2.write_text("Event ID: 4624 - Login successful")
        
        print("[TEST] Generating manifest for synthetic evidence...")
        manifest = generate_manifest(tmp_path)
        
        if (tmp_path / "manifest.json").exists():
            print("[PASS] Manifest created.")
        else:
            print("[FAIL] Manifest not created.")
            
        # 2. Verify integrity
        print("[TEST] Verifying manifest (Expected: INTACT)...")
        result = verify_manifest(tmp_path)
        print(f"Result: {result['status']}")
        if result['status'] == "INTACT":
            print("[PASS] Integrity verified.")
        else:
            print(f"[FAIL] Integrity verification failed: {result.get('tampered_files')}")
            
        # 3. Simulate tampering
        print("[TEST] Simulating tampering of evidence1.txt...")
        if platform.system() == "Windows":
             # We might need to remove read-only if we were testing the file itself, 
             # but here we tamper evidence1.txt which isn't read-only by generate_manifest (only manifest.json is)
             pass
        
        file1.write_text("Integrity is compromised!")
        
        print("[TEST] Verifying manifest (Expected: TAMPERED)...")
        result = verify_manifest(tmp_path)
        print(f"Result: {result['status']}")
        if result['status'] == "TAMPERED":
            print("[PASS] Tamper detection successful.")
        else:
            print("[FAIL] Tamper detection failed.")
            
    print("--- Self-Test Complete ---")
