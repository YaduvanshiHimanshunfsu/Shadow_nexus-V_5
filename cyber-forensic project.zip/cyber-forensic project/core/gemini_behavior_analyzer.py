"""
Gemini Behavior Analyzer
Detect anomalous user behavior and automated/bot activity
"""

import google.generativeai as genai
import json
from datetime import datetime
from typing import Dict, Any, List

from utils.model_selector import model_selector


class GeminiBehaviorAnalyzer:
    """
    Use Gemini to analyze user behavior patterns and detect anomalies
    No ML training required - Gemini learns patterns on the fly
    """
    
    def __init__(self, api_key: str, model_name: str = 'gemini-2.5-flash'):
        genai.configure(api_key=api_key)
        from utils.model_selector import model_selector
        from utils.cache_manager import CacheManager
        
        genai.configure(api_key=api_key)
        self.model_name = model_selector.validate_model(model_name)
        self.model = genai.GenerativeModel(self.model_name)
        self.user_baselines = {}  # Store user behavior baselines
        self.cache = CacheManager(cache_dir="./cache/behavior", ttl_seconds=3600*12)
    
    def analyze_keystroke_pattern(self, keystroke_timings: List[int]) -> Dict[str, Any]:
        """
        Analyze if keystrokes are human or automated
        """
        if not keystroke_timings:
            return self._error_response("Empty timing data")

        from prompts.enhanced_prompts import BEHAVIOR_ANALYSIS_PROMPT
        
        # Cache Check
        cache_key = self.cache.generate_cache_key(str(keystroke_timings))
        cached = self.cache.get_cached_response(cache_key)
        if cached:
            return cached

        prompt = BEHAVIOR_ANALYSIS_PROMPT.format(keystroke_timings=keystroke_timings)
        
        try:
            response = self.model.generate_content(prompt, request_options={"timeout": 10})
            result = self._parse_json_response(response.text)
            result['analysis_timestamp'] = datetime.now().isoformat()
            result['fallback_mode'] = False
            
            # Cache it
            self.cache.cache_response(cache_key, result)
            
            return result
        except Exception as e:
            return self._rule_based_keystroke_fallback(keystroke_timings, str(e))
    
    def _rule_based_keystroke_fallback(self, timings: List[int], error_msg: str) -> Dict[str, Any]:
        """Statistical fallback when API is down"""
        import statistics
        
        if len(timings) < 2:
            return self._error_response(f"Insufficient data for fallback. Error: {error_msg}")
            
        mean = statistics.mean(timings)
        stdev = statistics.stdev(timings) if len(timings) > 1 else 0
        cv = stdev / mean if mean > 0 else 0
        
        # Heuristic: BOT if CV < 0.1 (very consistent) or mean < 30ms (superhuman speed)
        is_bot = cv < 0.1 or mean < 30
        
        return {
            "input_type": "bot" if is_bot else "human",
            "is_human": not is_bot,
            "confidence": 0.7,
            "evidence": ["Consistency-based heuristic (CV < 0.1)" if is_bot else "Natural variance detected"],
            "statistical_summary": {
                "mean_interval": mean,
                "std_deviation": stdev,
                "cv": cv
            },
            "assessment": f"Rule-based fallback due to API error: {error_msg}",
            "fallback_mode": True,
            "analysis_timestamp": datetime.now().isoformat()
        }

    def analyze_user_activity_sequence(self, user_id: str, recent_activities: List[Dict]) -> Dict[str, Any]:
        """
        Detect if user's current activities match their normal behavior
        """
        baseline = self.user_baselines.get(user_id, "No baseline available")
        
        prompt = f"""
You are analyzing user activity for anomalous behavior that might indicate account compromise or malicious insider.

USER ID: {user_id}

NORMAL BASELINE BEHAVIOR:
{baseline}

RECENT ACTIVITIES (last 30 minutes):
{json.dumps(recent_activities, indent=2)}

TASK: Determine if recent activities are consistent with this user's normal behavior.

Consider:
1. Time of day (does user normally work at this hour?)
2. Applications used (are these typical for this user?)
3. Data access patterns (accessing sensitive files they don't normally use?)
4. Command executions (running admin tools they've never used?)
5. Network connections (connecting to unusual systems?)
6. Volume and velocity of activities

Respond in JSON:
{{
  "anomaly_detected": true/false,
  "confidence": 0.0-1.0,
  "anomalous_activities": ["list specific unusual activities"],
  "severity": "CRITICAL|HIGH|MEDIUM|LOW",
  "possible_explanation": "compromised_account|insider_threat|legitimate_change|normal_behavior",
  "recommended_action": "immediate_investigation|monitor_closely|no_action",
  "reasoning": "Explain why this is/isn't anomalous",
  "risk_score": 0-100
}}

IMPORTANT: Respond ONLY with valid JSON.
"""
        
        try:
            response = self.model.generate_content(prompt, request_options={"timeout": 12})
            result = self._parse_json_response(response.text)
            result['user_id'] = user_id
            result['analysis_timestamp'] = datetime.now().isoformat()
            result['fallback_mode'] = False
            return result
        except Exception as e:
            # Simple heuristic for user activity fallback
            return {
                "anomaly_detected": False,
                "confidence": 0.5,
                "reasoning": f"Fallback mode active. Error: {str(e)}",
                "risk_score": 0,
                "fallback_mode": True,
                "analysis_timestamp": datetime.now().isoformat()
            }
    
    def build_user_baseline(self, user_id: str, historical_activities: List[Dict]) -> str:
        """
        Let Gemini create a behavioral baseline for a user
        """
        prompt = f"""
Analyze this user's historical activity and create a behavioral baseline profile.

USER ID: {user_id}

HISTORICAL ACTIVITIES (past 30 days):
{json.dumps(historical_activities[:100], indent=2)}

TASK: Create a behavioral profile summarizing:
1. Normal working hours
2. Typical applications/tools used
3. Common file access patterns
4. Usual network/system connections
5. Administrative activity frequency
6. Any notable patterns or routines
7. Typical activity volume per day

Provide a concise baseline profile (200-300 words) that can be used to detect future anomalies.
Focus on patterns, not individual events.
"""
        
        try:
            response = self.model.generate_content(prompt, request_options={"timeout": 20})
            baseline = response.text.strip()
            self.user_baselines[user_id] = baseline
            return baseline
        except Exception as e:
            return f"Baseline compilation suspended (API Down). Error: {str(e)}"
    
    def analyze_command_sequence(self, command_sequence: List[str]) -> Dict[str, Any]:
        """
        Analyze sequence of commands for attack patterns
        """
        prompt = f"""
Analyze this sequence of commands for attack patterns.

COMMAND SEQUENCE:
{json.dumps(command_sequence, indent=2)}

TASK: Identify if this sequence represents an attack pattern.

Look for:
1. Reconnaissance commands (whoami, net user, ipconfig)
2. Privilege escalation attempts
3. Lateral movement (PsExec, WMI, RDP)
4. Credential dumping (mimikatz, procdump)
5. Anti-forensics (log clearing, timestomping)
6. Data exfiltration preparation
7. Ransomware preparation (shadow copy deletion, backup deletion)

Respond in JSON:
{{
  "is_attack_sequence": true/false,
  "confidence": 0.0-1.0,
  "attack_phase": "reconnaissance|initial_access|execution|persistence|privilege_escalation|defense_evasion|credential_access|discovery|lateral_movement|collection|exfiltration|impact",
  "severity": "CRITICAL|HIGH|MEDIUM|LOW",
  "explanation": "What this sequence indicates",
  "next_likely_steps": ["predicted next attacker actions"],
  "mitre_attack_ttps": ["T1078", "T1003"],
  "recommended_response": "immediate_containment|monitor|investigate"
}}

IMPORTANT: Respond ONLY with valid JSON.
"""
        
        try:
            response = self.model.generate_content(prompt, request_options={"timeout": 15})
            result = self._parse_json_response(response.text)
            result['analysis_timestamp'] = datetime.now().isoformat()
            result['fallback_mode'] = False
            return result
        except Exception as e:
            return self._rule_based_sequence_fallback(command_sequence, str(e))

    def _rule_based_sequence_fallback(self, sequence: List[str], error_msg: str) -> Dict[str, Any]:
        """Keyword-based sequence analysis fallback"""
        attack_keywords = {
            'reconnaissance': ['whoami', 'net user', 'ipconfig', 'hostname'],
            'anti-forensics': ['wevtutil', 'vssadmin', 'fsutil', 'clearev'],
            'cred-dump': ['mimikatz', 'procdump', 'lsass'],
            'lateral': ['psexec', 'mstsc', 'net use']
        }
        
        detected_categories = []
        for cmd in sequence:
            cmd_lower = cmd.lower()
            for cat, kws in attack_keywords.items():
                if any(kw in cmd_lower for kw in kws):
                    detected_categories.append(cat)
        
        is_attack = len(set(detected_categories)) >= 1
        
        return {
            "is_attack_sequence": is_attack,
            "confidence": 0.6 if is_attack else 0.0,
            "attack_phase": "defense_evasion" if "anti-forensics" in detected_categories else "discovery",
            "explanation": f"Rule-based sequence fallback. Error: {error_msg}",
            "severity": "HIGH" if is_attack else "LOW",
            "fallback_mode": True,
            "analysis_timestamp": datetime.now().isoformat()
        }
    
    def _parse_json_response(self, response_text: str) -> Dict[str, Any]:
        """Parse JSON from Gemini response"""
        response_text = response_text.strip()
        
        if response_text.startswith('```json'):
            response_text = response_text[7:]
        if response_text.startswith('```'):
            response_text = response_text[3:]
        if response_text.endswith('```'):
            response_text = response_text[:-3]
        
        response_text = response_text.strip()
        
        try:
            return json.loads(response_text)
        except json.JSONDecodeError:
            # Last ditch cleaning
            try:
                import re
                match = re.search(r'\{.*\}', response_text, re.DOTALL)
                if match:
                    return json.loads(match.group())
            except:
                pass
            return {
                'error': 'JSON parsing failed',
                'raw_response': response_text[:500]
            }
    
    def _error_response(self, error_message: str) -> Dict[str, Any]:
        """Generate standardized error response"""
        return {
            'error': error_message,
            'confidence': 0.0,
            'analysis_timestamp': datetime.now().isoformat()
        }
