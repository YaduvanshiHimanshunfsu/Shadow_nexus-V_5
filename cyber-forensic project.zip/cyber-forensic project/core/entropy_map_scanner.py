import os
import struct
import time
import json
import logging
import threading
import numpy as np
from pathlib import Path
from typing import Dict, List, Any, Optional
from scipy.stats import kstest
from core.structured_logger import get_logger
from core.watchdog import watchdog
from core.alert_deduplication import deduplicator
from core.performance_monitor import timed, perf
from core.alert_manager import AlertSeverity, AlertChannel

logger = get_logger("entropy_scanner")

class EntropyMapScanner(threading.Thread):
    """
    Scans unallocated clusters for hidden encrypted volumes and wipe patterns.
    Uses Shannon entropy and K-S tests for statistical anomaly detection.
    """
    
    def __init__(self, config: Dict[str, Any], evidence_collector=None, alert_mgr=None):
        super().__init__(daemon=True, name="EntropyScanner")
        self.config = config.get('shadownet_v5', {}).get('entropy_scanner', {})
        self.c4_config = config.get('shadownet', {})
        self.evidence_collector = evidence_collector
        self.alert_mgr = alert_mgr
        self.running = False
        
        self.volume_path = self.config.get('volume', 'C:')
        self.poll_interval = self.config.get('poll_interval_seconds', 300)
        self.min_hidden_clusters = self.config.get('hidden_volume_min_clusters', 50000)
        self.entropy_threshold = self.config.get('hidden_volume_entropy_threshold', 7.85)
        self.alert_threshold = self.config.get('wipe_confidence_alert_threshold', 0.80)
        
        self.handle = None
        self.cluster_size = 4096  # Default, updated from boot sector
        self.total_clusters = 0
        self._read_offset_delta = 0 # FIX 5
        
    def _open_volume(self) -> bool:
        try:
            if os.name == 'nt':
                import ctypes
                path = f"\\\\.\\{self.volume_path.strip('\\').strip(':')}:"
                self.handle = ctypes.windll.kernel32.CreateFileW(
                    path, 0x80000000, 0x00000001 | 0x00000002, None, 3, 0, None)
                if self.handle == -1:
                    self.handle = None
                    return False
            else:
                self.handle = open(self.volume_path, 'rb')
            return True
        except Exception:
            return False

    def _read_boot_sector(self) -> bool:
        try:
            self.seek_volume(0)
            data = self.read_volume(512)
            if not data or data[510:512] != b'\x55\xAA':
                return False
            
            # bytes per sector @ 0x0B, sectors per cluster @ 0x0D
            bps = struct.unpack('<H', data[11:13])[0]
            spc = data[13]
            self.cluster_size = bps * spc
            return True
        except Exception:
            return False

    def seek_volume(self, offset: int):
        if os.name == 'nt':
            import ctypes
            li = ctypes.c_int64(offset)
            res = ctypes.windll.kernel32.SetFilePointerEx(self.handle, li, None, 0)
            if not res:
                logger.error(f"SetFilePointerEx failed: {ctypes.WinError()}")
            self._read_offset_delta = 0 # Offset alignment not strictly needed with SetFilePointerEx on most volumes, but kept for safety if provided previously
        else:
            self.handle.seek(offset)

    def read_volume(self, size: int) -> bytes:
        if os.name == 'nt':
            import ctypes
            buffer = ctypes.create_string_buffer(size)
            bytes_read = ctypes.c_ulong(0)
            ok = ctypes.windll.kernel32.ReadFile(self.handle, buffer, size, ctypes.byref(bytes_read), None)
            if not ok: return b''
            return buffer.raw[:bytes_read.value]
        else:
            return self.handle.read(size)

    def _read_bitmap_stream(self):
        """Streams $Bitmap cluster-by-cluster to save RAM (FIX 6)."""
        try:
            self.seek_volume(0)
            boot = self.read_volume(512)
            if boot[3:11] != b'NTFS    ': return
            
            mft_cluster = struct.unpack('<Q', boot[0x30:0x38])[0]
            mft_offset = mft_cluster * self.cluster_size
            
            self.seek_volume(mft_offset + (6 * 1024))
            rec_6 = self.read_volume(1024)
            if rec_6[:4] != b'FILE': return

            attr_off = struct.unpack('<H', rec_6[0x14:0x16])[0]
            curr = attr_off
            while curr < 1022:
                a_type = struct.unpack('<I', rec_6[curr:curr+4])[0]
                if a_type == 0xFFFFFFFF: break
                a_len = struct.unpack('<I', rec_6[curr+4:curr+8])[0]
                if a_type == 0x80: # $DATA
                    res = rec_6[curr+8]
                    if res == 0: # Resident
                        content_off = struct.unpack('<H', rec_6[curr+20:curr+22])[0]
                        content_len = struct.unpack('<I', rec_6[curr+16:curr+20])[0]
                        bitmap_data = rec_6[curr+content_off : curr+content_off+content_len]
                        for i, byte in enumerate(bitmap_data):
                            yield i, byte
                        return
                    else: # Non-resident
                        run_off = struct.unpack('<H', rec_6[curr+32:curr+34])[0]
                        runs_raw = rec_6[curr+run_off : curr+a_len]
                        alloc_size = struct.unpack('<Q', rec_6[curr+40:curr+48])[0]
                        
                        # Parse runs and stream
                        offset = 0
                        curr_cluster = 0
                        byte_counter = 0
                        while offset < len(runs_raw) and byte_counter < alloc_size:
                            header = runs_raw[offset]
                            if header == 0: break
                            len_sz, off_sz = header & 0x0F, (header & 0xF0) >> 4
                            offset += 1
                            length = 0
                            for i in range(len_sz): length |= (runs_raw[offset+i] << (i*8))
                            offset += len_sz
                            rel_off = 0
                            for i in range(off_sz):
                                val = runs_raw[offset+i]
                                if i == off_sz-1 and (val & 0x80): rel_off |= ((val | ~0xFF) << (i*8))
                                else: rel_off |= (val << (i*8))
                            offset += off_sz
                            curr_cluster += rel_off
                            
                            # Read in 1MB chunks
                            chunk_clusters = (1024*1024) // self.cluster_size
                            for c in range(0, length, chunk_clusters):
                                batch = min(chunk_clusters, length - c)
                                self.seek_volume((curr_cluster + c) * self.cluster_size)
                                chunk_data = self.read_volume(batch * self.cluster_size)
                                for b in chunk_data:
                                    if byte_counter < alloc_size:
                                        yield byte_counter, b
                                        byte_counter += 1
                                    else: return
                        return
                curr += a_len
        except Exception as e:
            logger.error(f"Bitmap stream error: {e}")

    def _read_data_runs(self, runs_raw: bytes, total_size: int) -> bytes:
        """Parses NTFS data runs and reads the actual data blocks."""
        data = bytearray()
        offset = 0
        curr_cluster = 0
        
        while offset < len(runs_raw) and len(data) < total_size:
            header = runs_raw[offset]
            if header == 0: break
            
            len_sz = header & 0x0F
            off_sz = (header & 0xF0) >> 4
            offset += 1
            
            length = 0
            for i in range(len_sz):
                length |= (runs_raw[offset+i] << (i * 8))
            offset += len_sz
            
            rel_offset = 0
            for i in range(off_sz):
                # Signed conversion for relative offset
                val = runs_raw[offset+i]
                if i == off_sz - 1 and (val & 0x80):
                    rel_offset |= ((val | ~0xFF) << (i * 8))
                else:
                    rel_offset |= (val << (i * 8))
            offset += off_sz
            
            curr_cluster += rel_offset
            
            # Read clusters
            self.seek_volume(curr_cluster * self.cluster_size)
            chunk = self.read_volume(length * self.cluster_size)
            data.extend(chunk)
            
        return bytes(data[:total_size])

    def block_entropy(self, data: bytes) -> float:
        if not data: return 0.0
        arr = np.frombuffer(data, dtype=np.uint8)
        counts = np.bincount(arr, minlength=256)
        probs = counts[counts > 0] / len(arr)
        return -np.sum(probs * np.log2(probs))

    def detect_wipe_signature(self, data: bytes, entropies: np.ndarray) -> Dict:
        """Corrected post-wipe signature detection (FIX 4)."""
        if len(entropies) == 0: return {"verdict": "CLEAN", "confidence": 0.0}
        mean_ent = np.mean(entropies)
        std_ent = np.std(entropies)
        
        # 1. Random Pass Wipe (DoD Final / Random)
        if mean_ent > 7.8 and std_ent < 0.1:
            has_magic = False
            for i in range(0, len(data), self.cluster_size):
                chunk = data[i:i+16]
                if len(chunk) < 4: continue
                if chunk[:2] in [b'MZ', b'PK', b'\xff\xd8', b'\x89\x50'] or chunk[:4] == b'%PDF':
                    has_magic = True; break
            
            if not has_magic:
                return {
                    "verdict": "WIPE_PATTERN_DETECTED",
                    "confidence": 0.95,
                    "desc": f"Random/DoD wipe signature confirmed (mean={mean_ent:.3f}, std={std_ent:.3f})"
                }
        
        # 2. Solid wipes (0x00 or 0xFF)
        if mean_ent < 0.01:
            first_cluster = data[:self.cluster_size]
            if all(b == 0 for b in first_cluster):
                return {"verdict": "WIPE_PATTERN_DETECTED", "confidence": 0.99, "desc": "Pure 0x00 forensic wipe."}
            if all(b == 255 for b in first_cluster):
                return {"verdict": "WIPE_PATTERN_DETECTED", "confidence": 0.99, "desc": "Pure 0xFF forensic wipe."}
                
        return {"verdict": "CLEAN", "confidence": 0.0}

    def _chi_squared_test(self, data: bytes) -> float:
        """Chi-sq test: measures evidence of non-randomness."""
        if not data: return 0.0
        observed = np.bincount(np.frombuffer(data, dtype=np.uint8), minlength=256)
        expected = len(data) / 256.0
        chi_sq = np.sum((observed - expected)**2 / expected)
        return float(chi_sq)

    def _monte_carlo_pi_test(self, data: bytes) -> float:
        """Estimates Pi using data as (x,y) coordinates. Encrypted data converges to 3.14."""
        if len(data) < 2000: return 0.0
        # Use byte pairs as coordinates (scaled to 0-1)
        coords = np.frombuffer(data, dtype=np.uint8).astype(float) / 255.0
        x = coords[0::2]
        y = coords[1::2]
        dist = x**2 + y**2
        inside = np.sum(dist <= 1.0)
        pi_est = (4.0 * inside) / len(x)
        return float(pi_est)

    def _write_heatmap(self, entropies: List[float]):
        """Writes binary entropy heatmap for dashboard visualization."""
        heatmap_file = self.config.get('heatmap_file', 'evidence/artifacts/entropy_heatmap.bin')
        try:
            with open(heatmap_file, 'ab') as f:
                f.write(struct.pack(f'{len(entropies)}f', *entropies))
        except Exception: pass

    def scan_unallocated(self) -> List[Dict[str, Any]]:
        findings = []
        
        runs = []
        curr_run = None
        for i, byte_val in self._read_bitmap_stream():
            for bit_idx in range(8):
                cluster_idx = i * 8 + bit_idx
                if not (byte_val & (1 << bit_idx)):
                    if curr_run is None:
                        curr_run = [cluster_idx, 1]
                    else:
                        curr_run[1] += 1
                else:
                    if curr_run:
                        if curr_run[1] > 100:
                            runs.append(curr_run)
                        curr_run = None
                    
        for start_cluster, length in runs:
            try:
                # Read a larger sample for enterprise verification
                sample_clusters = min(length, 2000)
                self.seek_volume(start_cluster * self.cluster_size)
                data = self.read_volume(sample_clusters * self.cluster_size)
                
                entropies = []
                for i in range(0, len(data), self.cluster_size):
                    block = data[i:i+self.cluster_size]
                    entropies.append(self.block_entropy(block))
                
                ent_arr = np.array(entropies)
                mean_ent = np.mean(ent_arr)
                
                # Binary Heatmap for PS2 Mapping requirement
                self._write_heatmap(entropies)
                
                run_verdicts = []

                # 1. Hidden Volume Detection (PS2) - ENTERPRISE FACTOR SYNTHESIS
                if mean_ent > self.entropy_threshold and length >= self.min_hidden_clusters:
                    # Test A: K-S Uniformity
                    ks_stat, p_val = kstest(ent_arr / 8.0, 'uniform')
                    # Test B: Chi-Squared
                    chi_val = self._chi_squared_test(data)
                    # Test C: Monte Carlo Pi
                    pi_val = self._monte_carlo_pi_test(data)
                    
                    # VeraCrypt/TrueCrypt specific: chi-squared for random data 
                    # with 255 degrees of freedom should be near 256.
                    is_truly_random = (200 < chi_val < 320)
                    is_pi_close = (3.10 < pi_val < 3.20)
                    
                    if p_val > 0.05 and is_truly_random and is_pi_close:
                        run_verdicts.append({
                            "verdict": "HIDDEN_VOLUME_CONFIRMED",
                            "confidence": 0.98,
                            "description": f"Verified Hidden Volume in {length} clusters. Entropy={mean_ent:.3f}, ChiSq={chi_val:.1f}, PiEst={pi_val:.4f}. Multi-pass statistical confirmation."
                        })
                    elif mean_ent > 7.9:
                        run_verdicts.append({
                            "verdict": "HIGH_ENTROPY_ANOMALY",
                            "confidence": 0.85,
                            "description": f"Potential Hidden Volume. Entropy={mean_ent:.3f}, but failed ChiSq/Pi convergence (possible compressed file)."
                        })
                
                # 2. Wipe Pattern Detection
                wipe = self.detect_wipe_signature(data, ent_arr)
                if wipe["verdict"] != "CLEAN":
                    run_verdicts.append({
                        "verdict": wipe["verdict"],
                        "confidence": wipe["confidence"],
                        "description": wipe["desc"]
                    })

                for rv in run_verdicts:
                    findings.append({
                        "start_cluster": start_cluster,
                        "length_clusters": length,
                        "mean_entropy": float(mean_ent),
                        "verdict": rv["verdict"],
                        "confidence": rv["confidence"],
                        "description": rv["description"],
                        "source_artifact": "$Bitmap",
                        "timestamp": time.time()
                    })
            except Exception as e:
                logger.error(f"Error scanning run {start_cluster}: {e}")
                
        return findings

    def run(self):
        self.running = True
        logger.info("Entropy Map Scanner starting...")
        
        while self.running:
            watchdog.heartbeat("entropy_scanner")
            try:
                if not self.handle:
                    if not self._open_volume():
                        time.sleep(self.poll_interval)
                        continue
                    if not self._read_boot_sector():
                        time.sleep(self.poll_interval)
                        continue
                
                logger.debug("Scanning unallocated space...")
                findings = self.scan_unallocated()
                
                for f in findings:
                    if f["confidence"] >= self.alert_threshold:
                        if deduplicator.is_duplicate(f["verdict"], f["description"]):
                            continue
                            
                        if hasattr(self, 'narrative_queue'):
                            self.narrative_queue.put(f)
                            
                        if self.evidence_collector:
                            self.evidence_collector.on_threat_detected(f)
                        if self.alert_mgr:
                            self.alert_mgr.send_alert(
                                title=f"Disk Anomaly: {f['verdict']}",
                                message=f["description"],
                                severity=AlertSeverity.HIGH,
                                channels=[AlertChannel.CONSOLE],
                                metadata=f
                            )
                        
                        # Bridge to main incident queue for reporting
                        if hasattr(self, 'incident_callback') and self.incident_callback:
                            self.incident_callback(f)
                
                summary_file = self.config.get('summary_file', 'evidence/artifacts/entropy_summary.json')
                Path(summary_file).parent.mkdir(parents=True, exist_ok=True)
                with open(summary_file, 'w') as sf:
                    json.dump(findings, sf, indent=2)
                    
            except Exception as e:
                logger.error(f"Entropy scan loop error: {e}")
                
            time.sleep(self.poll_interval)

    def stop(self):
        self.running = False
        if self.handle:
            if os.name == 'nt':
                import ctypes
                ctypes.windll.kernel32.CloseHandle(self.handle)
            else:
                self.handle.close()
            self.handle = None
