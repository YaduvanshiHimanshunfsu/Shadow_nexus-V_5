import time, threading, numpy as np
from collections import defaultdict
from contextlib import contextmanager
from pathlib import Path
import json
from datetime import datetime, timezone
from core.structured_logger import get_logger

logger = get_logger("perf_monitor")

class PerformanceMonitor:
    def __init__(self, max_samples: int = 1000):
        self._data: dict[str, list[float]] = defaultdict(list)
        self._lock = threading.Lock()
        self.max_samples = max_samples

        # Alerting thresholds (operation → max acceptable p99 ms)
        self.thresholds = {
            "ntfs_mft_record_parse_ms":    0.1,
            "entropy_block_batch_ms":       50.0,
            "behavior_analysis_ms":         50.0,
            "gemini_api_call_ms":           30000.0,
            "snapshot_capture_ms":          5000.0,
            "manifest_generation_ms":       500.0,
        }

    def record(self, operation: str, duration_ms: float):
        with self._lock:
            samples = self._data[operation]
            samples.append(duration_ms)
            if len(samples) > self.max_samples:
                samples.pop(0)

    def stats(self, operation: str) -> dict:
        with self._lock:
            samples = list(self._data.get(operation, []))
        if not samples:
            return {"operation": operation, "count": 0}
        arr = np.array(samples)
        result = {
            "operation": operation,
            "count": len(samples),
            "mean_ms":  round(float(np.mean(arr)), 3),
            "p50_ms":   round(float(np.percentile(arr, 50)), 3),
            "p95_ms":   round(float(np.percentile(arr, 95)), 3),
            "p99_ms":   round(float(np.percentile(arr, 99)), 3),
            "max_ms":   round(float(np.max(arr)), 3),
            "min_ms":   round(float(np.min(arr)), 3),
        }
        threshold = self.thresholds.get(operation)
        if threshold:
            result["threshold_ms"] = threshold
            result["breaching"] = result["p99_ms"] > threshold
        return result

    def all_stats(self) -> list[dict]:
        with self._lock:
            ops = list(self._data.keys())
        return [self.stats(op) for op in ops]

    def breaching_thresholds(self) -> list[dict]:
        return [s for s in self.all_stats() if s.get("breaching")]

    def write_report(self, output_dir: Path):
        output_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "metrics": self.all_stats(),
            "breaching": self.breaching_thresholds()
        }
        path = output_dir / f"performance_{ts}.json"
        path.write_text(json.dumps(report, indent=2))
        return path

@contextmanager
def timed(monitor: PerformanceMonitor, operation: str):
    start = time.perf_counter_ns()
    try:
        yield
    finally:
        ms = (time.perf_counter_ns() - start) / 1e6
        monitor.record(operation, ms)

# Global singleton
perf = PerformanceMonitor()
