import ctypes, os, platform
from dataclasses import dataclass
from core.structured_logger import get_logger

logger = get_logger("privilege_manager")

OPERATION_TIERS = {
    "raw_disk_read":      0,
    "keyboard_hook_ll":   0,
    "evdev_access":       0,
    "event_log_export":   0,
    "vss_snapshot":       0,
    "process_enum_all":   1,
    "network_enum":       1,
    "evidence_write":     2,
    "gemini_api":         2,
    "report_generation":  2,
    "siem_forward":       2,
    "alert_send":         2,
}

@dataclass
class PrivilegeCapabilities:
    tier: int
    raw_disk:       bool
    keyboard_hook:  bool
    event_logs:     bool
    process_enum:   bool
    evidence_write: bool

class PrivilegeManager:
    def __init__(self):
        self.os = platform.system()
        self.tier = self._detect_tier()
        self.caps = self._build_caps()
        self._log_report()

    def _detect_tier(self) -> int:
        if self.os == "Windows":
            try:
                return 0 if ctypes.windll.shell32.IsUserAnAdmin() else 2
            except Exception:
                return 2
        else:
            return 0 if os.geteuid() == 0 else 2

    def _build_caps(self) -> PrivilegeCapabilities:
        return PrivilegeCapabilities(
            tier=self.tier,
            raw_disk      = self.tier == 0,
            keyboard_hook = self.tier == 0,
            event_logs    = self.tier <= 1,
            process_enum  = self.tier <= 1,
            evidence_write= True,
        )

    def can_do(self, operation: str) -> bool:
        required = OPERATION_TIERS.get(operation, 2)
        return self.tier <= required

    def require(self, operation: str) -> None:
        if not self.can_do(operation):
            raise PermissionError(
                f"'{operation}' requires Tier "
                f"{OPERATION_TIERS[operation]} privileges. "
                f"Current tier: {self.tier}. "
                f"{'Run as Administrator.' if self.os == 'Windows' else 'Run as root.'}"
            )

    def _log_report(self):
        logger.info("Privilege report", extra={"event": "PRIVILEGE_REPORT",
            "data": {
                "tier": self.tier,
                "raw_disk":       self.caps.raw_disk,
                "keyboard_hook":  self.caps.keyboard_hook,
                "event_logs":     self.caps.event_logs,
                "process_enum":   self.caps.process_enum,
                "evidence_write": self.caps.evidence_write,
            }
        })

# Global singleton
privilege_manager = PrivilegeManager()
