#!/bin/bash
set -euo pipefail

INSTALL_DIR="/opt/shadownet"
VENV_DIR="$INSTALL_DIR/venv"
EVIDENCE_DIR="/var/shadownet/evidence"
LOG_DIR="/var/log/shadownet"

echo "[*] Installing ShadowNet Nexus v5.0..."

# Check root
[[ $EUID -ne 0 ]] && echo "Must run as root" && exit 1

# Create dirs
mkdir -p "$INSTALL_DIR" "$EVIDENCE_DIR" "$LOG_DIR"
mkdir -p "$EVIDENCE_DIR"/{artifacts,incidents,reports,emergency_snapshots}

# Copy files
cp -r ./* "$INSTALL_DIR/"

# Create venv and install deps
python3 -m venv "$VENV_DIR"
"$VENV_DIR/bin/pip" install --upgrade pip
"$VENV_DIR/bin/pip" install -r requirements_v5.txt

# Install and enable systemd service
cp deploy/shadownet.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable shadownet
systemctl start shadownet

echo "[OK] ShadowNet installed and running."
echo "[OK] Evidence vault: $EVIDENCE_DIR"
echo "[OK] Logs: $LOG_DIR"
systemctl status shadownet --no-pager
