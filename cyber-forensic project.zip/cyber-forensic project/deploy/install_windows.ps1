#Requires -RunAsAdministrator
$InstallDir = "C:\Program Files\ShadowNet"
$EvidenceDir = "C:\ShadowNet\Evidence"
$LogDir = "C:\ShadowNet\Logs"

Write-Host "[*] Installing ShadowNet Nexus v5.0..."

# Create directories
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
New-Item -ItemType Directory -Force -Path $EvidenceDir | Out-Null
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

# Copy files
Copy-Item -Recurse -Force ".\*" $InstallDir

# Install Python deps
Push-Location $InstallDir
python -m pip install -r requirements_v5.txt

# Install Windows Service
python deploy\shadownet_service_windows.py install
Set-Service -Name "ShadowNetNexus" -StartupType Automatic
Start-Service -Name "ShadowNetNexus"

Write-Host "[OK] ShadowNet installed as Windows Service."
Get-Service -Name "ShadowNetNexus"
