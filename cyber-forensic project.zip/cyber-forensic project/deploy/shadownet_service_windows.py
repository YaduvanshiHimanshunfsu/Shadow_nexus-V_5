import win32serviceutil, win32service, win32event, servicemanager
import threading
import sys
import os

# Ensure the parent directory is in the path so we can import shadownet_nexus_v5
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class ShadowNetService(win32serviceutil.ServiceFramework):
    _svc_name_         = "ShadowNetNexus"
    _svc_display_name_ = "ShadowNet Nexus v5.0 - Forensic Monitor"
    _svc_description_  = (
        "Real-time DFIR: live NTFS artifact parsing, entropy mapping, "
        "behavioral classification, LLM forensic synthesis."
    )

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self._stop_threading_event = threading.Event()
        self.main_thread = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.stop_event)
        self._stop_threading_event.set()
        if self.main_thread:
            self.main_thread.join(timeout=10)

    def SvcDoRun(self):
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, '')
        )
        self.main_thread = threading.Thread(
            target=self._run, daemon=False
        )
        self.main_thread.start()
        win32event.WaitForSingleObject(
            self.stop_event, win32event.INFINITE
        )

    def _run(self):
        try:
            from shadownet_nexus_v5 import run_main_loop
            run_main_loop(stop_event=self._stop_threading_event)
        except Exception as e:
            servicemanager.LogErrorMsg(f"ShadowNet execution failed: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == 'install':
        # Add LocalSystem and AutoStart logic if required by CLI
        pass
    win32serviceutil.HandleCommandLine(ShadowNetService)
