import os
import time
import subprocess
import random
import platform
import ctypes
from pathlib import Path

def is_admin():
    try:
        if platform.system() == "Windows":
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        else:
            return os.geteuid() == 0
    except:
        return False

def print_banner():
    print("="*60)
    print("🚀 SHADOWNET NEXUS v5.0 PRODUCTION REAL-TIME VERIFICATION 🚀")
    print("="*60)
    if not is_admin():
        print("⚠️  WARNING: NOT RUNNING AS ADMINISTRATOR")
        print("   NTFS Parser, Entropy Scanner, and Keyboard Hook will be DISABLED.")
        print("   Only V4 Process Detections can be verified.")
    else:
        print("✅ RUNNING AS ADMINISTRATOR - FULL V5.0 SUITE ACTIVE")
    print("="*60)

def trigger_v4_detections():
    print("\n[V4] Triggering Process Detections...")
    # Trigger VSS Manipulation alert
    print("   -> Triggering 'vssadmin list shadows'...")
    subprocess.run(["vssadmin", "list", "shadows"], capture_output=True)
    
    # Trigger Log Clearing Prep alert
    print("   -> Triggering 'wevtutil el'...")
    subprocess.run(["wevtutil", "el"], capture_output=True)
    
    # Trigger suspicious PowerShell alert (encoded command)
    print("   -> Triggering Suspicious PowerShell...")
    subprocess.run(["powershell", "-NoProfile", "-EncodedCommand", "RwBlAHQALQBQAHIAbwBjAGUAcwBzAA=="], capture_output=True)

def trigger_v5_entropy():
    if not is_admin(): return
    print("\n[V5] Triggering Entropy Anomaly...")
    # Create a file with high entropy (random data) in a temp location
    test_file = Path("C:/Temp/shadownet_entropy_test.dat")
    test_file.parent.mkdir(parents=True, exist_ok=True)
    
    print(f"   -> Writing 1MB of random data to {test_file}...")
    with open(test_file, "wb") as f:
        f.write(os.urandom(1024 * 1024))
    
    # The entropy scanner should pick up this new high-entropy cluster if it's scanning the volume
    print("   -> High entropy surface area created.")

def trigger_v5_ntfs():
    if not is_admin(): return
    print("\n[V5] Triggering NTFS Timestomp Discrepancy...")
    test_file = Path("C:/Temp/shadownet_ntfs_test.txt")
    test_file.parent.mkdir(parents=True, exist_ok=True)
    
    # Create a file
    with open(test_file, "w") as f:
        f.write("ShadowNet NTFS Test File")
    
    # Timestomp it using PowerShell to set it far in the past
    print(f"   -> Timestomping {test_file} to year 2000...")
    cmd = f'powershell -Command "(Get-Item \'{test_file}\').CreationTime = \'01/01/2000 00:00:00\'"'
    subprocess.run(cmd, shell=True)
    
    print("   -> MFT/USN discrepancy generated.")

def main():
    print_banner()
    
    # Give the user a moment to start ShadowNet if they haven't
    print("\nEnsure 'python shadownet_nexus_v5.py' is running in another terminal.")
    time.sleep(3)
    
    trigger_v4_detections()
    trigger_v5_entropy()
    trigger_v5_ntfs()
    
    print("\n" + "="*60)
    print("✅ Real-time verification sequence completed.")
    print("Check 'evidence/logs/shadownet.jsonl' and 'evidence/incidents/' for findings.")
    print("="*60)

if __name__ == "__main__":
    main()
