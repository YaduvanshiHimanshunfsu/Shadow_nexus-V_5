import os
import sys
import time
import ctypes
import threading
import subprocess
from pathlib import Path

# Fix relative imports
sys.path.append(os.getcwd())

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if not is_admin():
    print("❌ ERROR: This master combat test requires Administrator privileges!")
    print("   Please right-click PowerShell or Command Prompt, select 'Run as Administrator',")
    print("   and run this script again.")
    sys.exit(1)

print("="*80)
print("🚀 SHADOWNET NEXUS v5.0 - LIVE COMBAT CAPABILITY TEST")
print("="*80)
print("WARNING: This test strictly verifies detection capabilities against LIVE ATTACKS.")
print("Ensure that 'python shadownet_nexus_v5.py' is running in another Administrator Terminal.")
print("="*80)
print("")

time.sleep(3)

test_files = []

def run_test(name, func):
    print(f"\n[▶] EXECUTING COMBAT SIMULATION: {name}")
    print("-" * 50)
    try:
        func()
        print(f"[✔] Action Completed. Check ShadowNet logs for detection.")
    except Exception as e:
        print(f"[X] Action Failed: {e}")
    time.sleep(3)

# -----------------------------------------------------------------------------
# Test 1: V4 Process Monitor (Command Logging & AI Analysis)
# -----------------------------------------------------------------------------
def test_process_monitor():
    print("    -> Simulating anti-forensics capability (clearing Windows Event Logs)...")
    subprocess.Popen(['cmd.exe', '/c', 'wevtutil cl Application'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print("    -> Simulating credential dumping via Mimikatz keyword...")
    subprocess.Popen(['cmd.exe', '/c', 'echo "Starting mimikatz.exe"'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# -----------------------------------------------------------------------------
# Test 2: V5 File Integrity Monitor (FIM)
# -----------------------------------------------------------------------------
def test_fim():
    print("    -> Dropping suspicious payload onto Desktop (mimikatz_test.exe)...")
    desktop = Path(os.path.join(os.environ.get('USERPROFILE', 'C:\\'), 'Desktop'))
    evil_file = desktop / "mimikatz_test.exe"
    evil_file.write_text("MZ \n Test Payload")
    test_files.append(evil_file)
    
    time.sleep(1)
    print("    -> Deleting dropped payload to trigger deletion alert...")
    if evil_file.exists():
        evil_file.unlink()

# -----------------------------------------------------------------------------
# Test 3: V5 Entropy Map Scanner (Hidden Volumes & Wiper Detection)
# -----------------------------------------------------------------------------
def test_entropy_wiper():
    print("    -> Creating high-entropy chunk simulating an encrypted container/wiper...")
    test_file = Path("C:\\entropy_test.dat")
    try:
        # Write 2MB of pure random data (Entropy ~7.99)
        with open(test_file, 'wb') as f:
            f.write(os.urandom(1024 * 1024 * 2))
        test_files.append(test_file)
        print("    -> Attempting to read back pure random data via raw IO to trigger entropy spike...")
        subprocess.Popen(['cmd.exe', '/c', f'type C:\\entropy_test.dat > NUL'], shell=True)
    except PermissionError:
        print("    [!] Overriding permissions required for C:\\ drive root write...")

# -----------------------------------------------------------------------------
# Test 4: V5 NTFS Artifact Parser (Timestomping)
# -----------------------------------------------------------------------------
def test_ntfs_timestomp():
    print("    -> Performing simulated timestomp via PowerShell...")
    test_file = Path("C:\\timestomp_test.txt")
    try:
        test_file.write_text("Hello World")
        test_files.append(test_file)
        
        # PowerShell command to change the visible Creation and Modification times backwards
        ps_cmd = f"""
        $file = Get-Item 'C:\\timestomp_test.txt';
        $file.CreationTime = (Get-Date).AddYears(-5);
        $file.LastWriteTime = (Get-Date).AddYears(-5);
        """
        subprocess.run(["powershell", "-Command", ps_cmd], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        print("    -> File timestamps altered to 5 years ago.")
        print("    -> The NTFS scanner in ShadowNet will catch this discrepancy on its next cycle (0-60s).")
    except PermissionError:
        print("    [!] Root C:\\ write access denied for timestomp test.")

# -----------------------------------------------------------------------------
# Test 5: V5 Behavioral Monitor (Keylogger & Bot Input)
# -----------------------------------------------------------------------------
def test_behavior():
    print("    -> Simulating automated bot keystroke injection (High speed, 0 variance)...")
    # Using python's ctypes to inject keyboard events directly to the OS stream
    import ctypes
    from ctypes import wintypes
    
    user32 = ctypes.WinDLL('user32', use_last_error=True)
    INPUT_KEYBOARD = 1
    KEYEVENTF_KEYUP = 0x0002

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = (("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                    ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)))

    class INPUT(ctypes.Structure):
        class _I(ctypes.Union):
            _fields_ = (("ki", KEYBDINPUT), ("mi", ctypes.c_int * 7), ("hi", ctypes.c_int * 2))
        _anonymous_ = ("i",)
        _fields_ = (("type", wintypes.DWORD), ("i", _I))

    def press_key(hexKeyCode):
        x = INPUT(type=INPUT_KEYBOARD,
                  ki=KEYBDINPUT(wVk=hexKeyCode, dwFlags=0))
        user32.SendInput(1, ctypes.byref(x), ctypes.sizeof(x))

    def release_key(hexKeyCode):
        x = INPUT(type=INPUT_KEYBOARD,
                  ki=KEYBDINPUT(wVk=hexKeyCode, dwFlags=KEYEVENTF_KEYUP))
        user32.SendInput(1, ctypes.byref(x), ctypes.sizeof(x))

    # Rapid fire 'A' key (0x41) 15 times with exactly 10ms variance
    for _ in range(15):
        press_key(0x41)
        time.sleep(0.01) # Unhumanly fast and precise
        release_key(0x41)
        time.sleep(0.01)

# -----------------------------------------------------------------------------
# Execution
# -----------------------------------------------------------------------------

run_test("1. Suspicious Process Execution", test_process_monitor)
run_test("2. File Integrity Tampering (FIM)", test_fim)
run_test("3. Entropy Map Scanner (Hidden Data)", test_entropy_wiper)
run_test("4. NTFS Timestomping ($MFT Discrepancy)", test_ntfs_timestomp)
run_test("5. Behavioral Keystroke Injection", test_behavior)

print("="*80)
print("✅ COMBAT SIMULATION COMPLETE")
print("="*80)
print("Please check the ShadowNet Nexus terminal and your 'evidence/' directory.")
print("The AI should be generating multiple court-ready markdown reports right now.")

# Cleanup
print("\nCleaning up test artifacts...")
for f in test_files:
    try:
        if f.exists():
            f.unlink()
    except Exception as e:
        print(f"Could not delete {f}: {e}")
