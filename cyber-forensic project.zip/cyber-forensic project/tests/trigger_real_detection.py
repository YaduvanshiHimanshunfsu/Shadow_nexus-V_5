import os
import subprocess
import time
from pathlib import Path

def trigger_detection():
    print("🚀 Triggering real-time detection for ShadowNet Nexus v5.0...")
    # This command should trigger the suspicious keyword detection for 'vssadmin'
    # We use a harmless version that just lists shadows
    try:
        subprocess.run(["vssadmin", "list", "shadows"], capture_output=True)
        print("✅ Command executed. Checking for evidence generation...")
    except Exception as e:
        print(f"❌ Failed to run command: {e}")

if __name__ == "__main__":
    trigger_detection()
