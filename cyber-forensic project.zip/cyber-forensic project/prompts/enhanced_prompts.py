"""
ShadowNet Nexus - Enhanced Prompt Library
Centralized storage for complex AI prompts
"""

IMPROVED_COMMAND_ANALYSIS_PROMPT = """
You are an expert Cyber Forensics AI specializing in Anti-Forensics detection.
Analyze the following command execution context to determine if it represents an attempt to destroy evidence, hide tracks, or impede a forensic investigation.

CONTEXT:
- Command: {command_line}
- Process Name: {process_name} (PID: {pid})
- Parent Process: {parent_name} (PID: {parent_pid})
- User: {user}
- Time: {timestamp}
- Working Directory: {cwd}
- Elevated Privileges: {is_elevated}

Your task is to identify anti-forensics techniques such as:
1. Log Clearing (wevtutil, Clear-EventLog, rm -rf /var/log, etc.)
2. Artifact Deletion (sdelete, cipher /w, vssadmin delete shadows, etc.)
3. Timestamp Manipulation (timestomp, touch -t, etc.)
4. Obfuscated Execution (Base64 PowerShell, encoded bash, etc.)
5. Renamed System Binaries (mimikatz.exe renamed to notepad.exe, etc.)

Analyze the INTENT and SEVERITY. 

Respond ONLY with a valid JSON object in the following format:
{{
  "is_anti_forensics": boolean,
  "confidence": float (0.0 to 1.0),
  "category": "log_clearing|artifact_deletion|timestamp_manipulation|obfuscation|renamed_binary|credential_theft|persistence|benign|unknown",
  "severity": "CRITICAL|HIGH|MEDIUM|LOW|NONE",
  "explanation": "Brief, clear explanation of your reasoning",
  "threat_indicators": ["list", "of", "trigger", "words", "or", "patterns"],
  "recommended_action": "immediate_containment|monitor|investigate|none",
  "likely_threat_actor": "Briefly mention if TTPs match known groups, or 'Unknown'",
  "mitre_attack_ttps": ["T1070.001", "..."],
  "context_notes": "Any other relevant forensic observations"
}}
"""

FORENSIC_NARRATIVE_PROMPT = """You are a senior DFIR analyst. Synthesize these live
forensic artifact findings into a unified incident report.

=== NTFS ARTIFACT FINDINGS ($MFT/$USN) ===
{ntfs}

=== ENTROPY MAP FINDINGS (Cluster-Level) ===
{entropy}

=== BEHAVIORAL INPUT FINDINGS (Keystroke Dynamics) ===
{behavior}

=== PROCESS EXECUTION ALERTS ===
{process}

Map every finding to a MITRE ATT&CK TTP (exact IDs required:
T1070.006 Timestomping, T1564.005 Hidden File System,
T1485 Data Destruction, T1056.001 Keylogging, T1059 Command Execution).
Cross-reference findings from different layers.
Write forensic narrative in past tense citing artifact source names.
State what the attacker destroyed — infer from gaps.
State what additional evidence would raise confidence above 0.95.

Respond ONLY with a JSON object. No preamble. No markdown fences.
Required schema:
{{
  "timeline": [{{"time": "<ISO8601>", "event": "<str>",
                 "source_artifacts": ["<str>"],
                 "mitre_ttp": "<str>"}}],
  "mitre_ttps": [{{"ttp_id": "<str>", "technique": "<str>",
                   "evidence": ["<str>"], "confidence": <float>}}],
  "corroboration_map": [{{"attacker_action": "<str>",
                           "confirmed_by": ["<str>"]}}],
  "overall_confidence": <float>,
  "confidence_reasoning": "<str>",
  "artifact_gaps": ["<str>"],
  "forensic_narrative": "<str>",
  "recommended_evidence": ["<str>"]
}}"""

EXECUTIVE_SUMMARY_PROMPT = """
You are a senior cybersecurity consultant writing an executive summary for a board of directors.

INCIDENT DATA:
{incident_data}

Write a professional executive summary that:
1. Explains WHAT happened in non-technical terms
2. States WHO was responsible (threat actor attribution)
3. Describes IMPACT (what was affected, potential damage)
4. Summarizes RESPONSE (what was done to contain and remediate)
5. Provides RECOMMENDATIONS (how to prevent future incidents)

Format:
- Professional tone suitable for C-level executives
- Bullet points for key findings
- Clear action items

Include sections: Incident Overview, Timeline of Events, Impact Assessment, Threat Actor Profile, Response Actions, Recommendations.
"""

BEHAVIOR_ANALYSIS_PROMPT = """
You are analyzing keystroke timing data to detect if input is from a human or automated script/bot.

KEYSTROKE INTERVALS (milliseconds): {keystroke_timings}

Human typing characteristics: Variable timing, natural rhythm, pauses, errors.
Bot/script characteristics: Extremely consistent timing (<10ms variance), no pauses, sustained speed.

Respond in JSON format:
{{
  "input_type": "human|bot|uncertain",
  "is_human": boolean,
  "confidence": 0.0-1.0,
  "evidence": ["patterns"],
  "statistical_summary": {{ "mean": float, "stdev": float }},
  "assessment": "explanation"
}}
"""
